import TrendInsightDashboard from './components/TrendInsightDashboard';

function App() {
  return <TrendInsightDashboard />;
}

export default App;

