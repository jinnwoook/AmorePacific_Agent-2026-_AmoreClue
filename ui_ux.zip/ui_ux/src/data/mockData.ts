export interface TrendSignal {
  type: 'SNS' | 'Retail' | 'Review';
  data: { name: string; value: number }[];
}

export type TrendStatus = '🌱 Early Trend' | '📈 Growing Trend' | '🚀 Actionable Trend' | '📉 Cooling';

export interface ReviewKeywords {
  positive: { keyword: string; count: number }[];
  negative: { keyword: string; count: number }[];
}
export type TrendType = 'Early Signal' | 'Actionable Trend';

export interface TrendItem {
  rank: number;
  category: string;
  combination: string;
  status: TrendStatus;
  trendType?: TrendType; // Early Signal 또는 Actionable Trend
  signals: TrendSignal[];
  insightText: string;
  combinationReason?: string; // 꿀조합인 이유 설명 (SNS/리테일/리뷰 데이터 기반)
  actionGuide?: string; // 트렌드 단계별 기획자 참고 방향성 힌트
  metrics?: TrendMetric[]; // 각 트렌드별 개별 지표
  evidence?: TrendEvidence; // AI 근거 설명 데이터 (꿀조합용)
  reviewKeywords?: ReviewKeywords; // 긍정/부정 리뷰 키워드 (꿀조합용)
}

export type Country = 'domestic' | 'usa' | 'japan' | 'singapore' | 'malaysia' | 'indonesia';

// 국가별 색상 테마
export const countryThemes: Record<Country, {
  primary: string;
  secondary: string;
  accent: string;
  gradient: string;
  name: string;
  flag: string;
}> = {
  domestic: {
    primary: 'rose',
    secondary: 'pink',
    accent: 'rose-400',
    gradient: 'from-rose-500 to-pink-500',
    name: '국내',
    flag: '🇰🇷',
  },
  usa: {
    primary: 'blue',
    secondary: 'indigo',
    accent: 'blue-400',
    gradient: 'from-blue-600 to-blue-400', // 미국 국기 파란색
    name: '미국',
    flag: '🇺🇸',
  },
  japan: {
    primary: 'red',
    secondary: 'rose',
    accent: 'red-400',
    gradient: 'from-red-600 to-red-400', // 일본 국기 빨간색
    name: '일본',
    flag: '🇯🇵',
  },
  singapore: {
    primary: 'emerald',
    secondary: 'red',
    accent: 'emerald-400',
    gradient: 'from-emerald-600 to-red-500', // 싱가포르 국기 (빨강+초록)
    name: '싱가포르',
    flag: '🇸🇬',
  },
  malaysia: {
    primary: 'blue',
    secondary: 'red',
    accent: 'blue-400',
    gradient: 'from-blue-600 to-red-500', // 말레이시아 국기 (파랑+빨강)
    name: '말레이시아',
    flag: '🇲🇾',
  },
  indonesia: {
    primary: 'red',
    secondary: 'red',
    accent: 'red-400',
    gradient: 'from-red-600 to-red-500', // 인도네시아 국기 빨간색
    name: '인도네시아',
    flag: '🇮🇩',
  },
};

export interface CombinationProduct {
  name: string;
  brand: string;
  imageUrl?: string; // 제품 이미지 URL
  mentionCount: number; // 함께 언급된 횟수
  rating?: number; // 평점
}

export interface TrendEvidence {
  reviewTrend: string; // 리뷰 추세 내용 요약
  numericalEvidence: {
    snsMentions: number; // SNS 언급 수
    reviewCount: number; // 리뷰 개수
    growthRate: number; // 성장률 (%)
    marketShare: number; // 시장 점유율 (%)
    previousMentions?: number; // 이전 기간 언급 수 (상승률 계산용)
    previousReviewCount?: number; // 이전 기간 리뷰 수 (성장률 계산용)
    coMentionCount?: number; // 함께 언급된 횟수 (꿀조합용)
    combinationProducts?: CombinationProduct[]; // 함께 조합된 제품 예시 (꿀조합용)
  };
  aiExplanation: string; // AI가 분석한 트렌드 근거 설명
  keywords?: string[]; // 주요 키워드 언급
  actionPlan?: string; // 행동 강령/활용 방안
}

export interface BubbleItem {
  id: string;
  name: string;
  type: 'ingredient' | 'formula' | 'effect';
  x: number;
  y: number;
  size: number;
  value: number;
  status?: TrendStatus; // Early Trend, Growing Trend, Actionable Trend, Cooling
  actionGuide?: string; // 트렌드 단계별 기획자 참고 방향성 힌트
  combinationReason?: string; // 꿀조합인 이유 설명 (SNS/리테일/리뷰 데이터 기반)
  evidence?: TrendEvidence; // AI 근거 설명 데이터
  reviewKeywords?: ReviewKeywords; // 긍정/부정 리뷰 키워드
  category?: string; // 대분류 카테고리 (스킨케어, 클렌징, 선케어, 메이크업, 헤어케어, 바디케어, 맨즈케어)
}

// 새로운 데이터 구조 타입 정의
export type MainCategory = 'Skincare' | 'Cleansing' | 'Sun Care' | 'Makeup' | 'Hair Care' | 'Body Care' | 'Mens Care';
export type ItemType = 'Ingredients' | 'Texture' | 'Effects';
export type TrendLevel = 'Actionable' | 'Growing' | 'Early';

export interface LeaderboardItem {
  rank?: number;
  keyword: string;
  score: number;
}

export type CategoryData = {
  [K in ItemType]?: {
    [L in TrendLevel]?: LeaderboardItem[];
  };
};

export type CountryLeaderboardData = {
  [K in MainCategory]?: CategoryData;
};

export interface ReportResult {
  type: 'marketing' | 'npd' | 'overseas';
  content: string;
}

export const trendData: TrendItem[] = [
  {
    rank: 1,
    category: 'Skincare',
    combination: '레티놀 + 앰플 + 모공 케어',
    status: '🚀 Actionable Trend',
    trendType: 'Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 45 },
          { name: 'Week 2', value: 52 },
          { name: 'Week 3', value: 61 },
          { name: 'Week 4', value: 68 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 82 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 95 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 38 },
          { name: 'Week 2', value: 44 },
          { name: 'Week 3', value: 51 },
          { name: 'Week 4', value: 58 },
          { name: 'Week 5', value: 65 },
          { name: 'Week 6', value: 72 },
          { name: 'Week 7', value: 79 },
          { name: 'Week 8', value: 86 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 42 },
          { name: 'Week 2', value: 48 },
          { name: 'Week 3', value: 55 },
          { name: 'Week 4', value: 62 },
          { name: 'Week 5', value: 69 },
          { name: 'Week 6', value: 76 },
          { name: 'Week 7', value: 83 },
          { name: 'Week 8', value: 90 },
        ],
      },
    ],
    insightText: '레티놀과 앰플 제형의 조합이 2030 모공 고민 고객층에서 8주 연속 상승세입니다.',
    combinationReason: '레티놀의 각질 제거 효과와 앰플의 고농축 전달력이 모공 케어에 시너지를 일으키며, SNS(95%), 리테일(86%), 리뷰(90%) 3가지 신호에서 모두 상승세를 보이고 있어 즉시 활용 가능한 트렌드입니다. 특히 SNS에서 8주간 지속적인 상승세를 보이며 2030 모공 고민 고객층에서 강한 관심을 받고 있습니다.',
    metrics: [
      { label: '성장률', value: 32.5, unit: '%', change: 8.2, trend: 'up' },
      { label: 'SNS 언급', value: 95, unit: '%', change: 12.5, trend: 'up' },
      { label: '판매 증가', value: 28.3, unit: '%', change: 6.1, trend: 'up' },
      { label: '긍정 리뷰', value: 92.5, unit: '%', change: 3.2, trend: 'up' },
      { label: '시장 점유', value: 18.7, unit: '%', change: 2.4, trend: 'up' },
      { label: '인지도', value: 75.2, unit: '%', change: 8.5, trend: 'up' },
    ],
  },
  {
    rank: 2,
    category: 'Suncare',
    combination: '아연옥사이드 + 선스틱 + 끈적임 없는',
    status: '📈 Growing Trend',
    trendType: 'Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 85 },
          { name: 'Week 2', value: 87 },
          { name: 'Week 3', value: 86 },
          { name: 'Week 4', value: 88 },
          { name: 'Week 5', value: 89 },
          { name: 'Week 6', value: 87 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 90 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 92 },
          { name: 'Week 2', value: 94 },
          { name: 'Week 3', value: 93 },
          { name: 'Week 4', value: 95 },
          { name: 'Week 5', value: 96 },
          { name: 'Week 6', value: 95 },
          { name: 'Week 7', value: 96 },
          { name: 'Week 8', value: 97 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 88 },
          { name: 'Week 2', value: 89 },
          { name: 'Week 3', value: 90 },
          { name: 'Week 4', value: 91 },
          { name: 'Week 5', value: 92 },
          { name: 'Week 6', value: 91 },
          { name: 'Week 7', value: 92 },
          { name: 'Week 8', value: 93 },
        ],
      },
    ],
    insightText: '끈적임 없는(Non-greasy) 무기자차(Zinc Oxide) 선스틱이 야외 활동 증가로 리테일 랭킹 1위 유지 중.',
    combinationReason: '무기자차의 안전한 자외선 차단과 선스틱의 휴대성, Non-greasy 포뮬러의 사용감이 결합되어 야외 활동 증가 시즌에 완벽한 제품으로 자리잡았습니다. SNS(90%), 리테일(97%), 리뷰(93%) 모두 안정적인 수준을 유지하고 있습니다.',
    actionGuide: '🏆 Stable 단계: 메인 제품 확장이나 조합 전략에 활용 가능. 검증된 트렌드이므로 기존 제품 라인업 확장이나 관련 제품군 개발에 적합합니다.',
    metrics: [
      { label: '성장률', value: 5.2, unit: '%', change: 0.8, trend: 'up' },
      { label: 'SNS 언급', value: 90, unit: '%', change: 2.1, trend: 'stable' },
      { label: '판매 증가', value: 3.5, unit: '%', change: 0.3, trend: 'up' },
      { label: '긍정 리뷰', value: 93, unit: '%', change: 0.5, trend: 'stable' },
      { label: '시장 점유', value: 25.3, unit: '%', change: 0.2, trend: 'stable' },
      { label: '인지도', value: 82.1, unit: '%', change: 1.2, trend: 'up' },
    ],
  },
  {
    rank: 3,
    category: 'Cleansing',
    combination: 'AHA/BHA + 클렌징 오일 + 블랙헤드',
    status: '🌱 Early Trend',
    trendType: 'Early Signal',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 15 },
          { name: 'Week 2', value: 22 },
          { name: 'Week 3', value: 31 },
          { name: 'Week 4', value: 42 },
          { name: 'Week 5', value: 55 },
          { name: 'Week 6', value: 68 },
          { name: 'Week 7', value: 78 },
          { name: 'Week 8', value: 88 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 12 },
          { name: 'Week 2', value: 18 },
          { name: 'Week 3', value: 25 },
          { name: 'Week 4', value: 35 },
          { name: 'Week 5', value: 48 },
          { name: 'Week 6', value: 62 },
          { name: 'Week 7', value: 72 },
          { name: 'Week 8', value: 82 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 18 },
          { name: 'Week 2', value: 25 },
          { name: 'Week 3', value: 33 },
          { name: 'Week 4', value: 44 },
          { name: 'Week 5', value: 57 },
          { name: 'Week 6', value: 70 },
          { name: 'Week 7', value: 80 },
          { name: 'Week 8', value: 90 },
        ],
      },
    ],
    insightText: '여름철 피지 관리를 위한 산성 성분 오일이 SNS에서 급상승 중인 초기 트렌드.',
    combinationReason: 'AHA/BHA의 각질 제거 효과와 오일의 모공 클렌징력이 결합되어 여름철 피지 관리에 효과적입니다. SNS(88%), 리테일(82%), 리뷰(90%)에서 8주간 급상승하며 초기 트렌드로 주목받고 있습니다.',
    actionGuide: '🌱 Early 단계: 테스트 제품이나 파일럿 기획에 적합. 빠른 성장세를 보이므로 조기 진입을 통해 시장 선점이 가능합니다.',
    metrics: [
      { label: '성장률', value: 48.2, unit: '%', change: 15.3, trend: 'up' },
      { label: 'SNS 언급', value: 88, unit: '%', change: 18.5, trend: 'up' },
      { label: '판매 증가', value: 35.7, unit: '%', change: 12.2, trend: 'up' },
      { label: '긍정 리뷰', value: 85.3, unit: '%', change: 5.8, trend: 'up' },
      { label: '시장 점유', value: 8.2, unit: '%', change: 1.5, trend: 'up' },
      { label: '인지도', value: 45.8, unit: '%', change: 12.3, trend: 'up' },
    ],
  },
  {
    rank: 4,
    category: 'Makeup',
    combination: '히알루론산 + 쿠션 + 광채',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 78 },
          { name: 'Week 2', value: 80 },
          { name: 'Week 3', value: 79 },
          { name: 'Week 4', value: 81 },
          { name: 'Week 5', value: 82 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 83 },
          { name: 'Week 8', value: 84 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 75 },
          { name: 'Week 2', value: 77 },
          { name: 'Week 3', value: 76 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 79 },
          { name: 'Week 6', value: 78 },
          { name: 'Week 7', value: 80 },
          { name: 'Week 8', value: 81 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 82 },
          { name: 'Week 2', value: 84 },
          { name: 'Week 3', value: 83 },
          { name: 'Week 4', value: 85 },
          { name: 'Week 5', value: 86 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 87 },
          { name: 'Week 8', value: 88 },
        ],
      },
    ],
    insightText: '촉촉한 광채(Glow) 피부 표현을 위한 히알루론산 쿠션이 건성 피부 타겟으로 인기.',
    combinationReason: '히알루론산의 강력한 보습력과 쿠션 제형의 밀착력이 결합되어 건성 피부 타겟에게 최적화되었습니다. SNS(84%), 리테일(81%), 리뷰(88%)에서 안정적인 수준을 유지하며 검증된 트렌드입니다.',
    actionGuide: '🏆 Stable 단계: 메인 제품 확장이나 조합 전략에 활용 가능. 검증된 트렌드이므로 기존 제품 라인업 확장이나 관련 제품군 개발에 적합합니다.',
    metrics: [
      { label: '성장률', value: 3.8, unit: '%', change: 0.5, trend: 'stable' },
      { label: 'SNS 언급', value: 84, unit: '%', change: 1.2, trend: 'stable' },
      { label: '판매 증가', value: 2.1, unit: '%', change: 0.3, trend: 'stable' },
      { label: '긍정 리뷰', value: 88, unit: '%', change: 0.8, trend: 'stable' },
      { label: '시장 점유', value: 15.2, unit: '%', change: 0.1, trend: 'stable' },
      { label: '인지도', value: 78.5, unit: '%', change: 1.5, trend: 'up' },
    ],
  },
  {
    rank: 5,
    category: 'Skincare',
    combination: '판테놀 + 크림 + 장벽 강화',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 52 },
          { name: 'Week 2', value: 58 },
          { name: 'Week 3', value: 65 },
          { name: 'Week 4', value: 72 },
          { name: 'Week 5', value: 79 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 91 },
          { name: 'Week 8', value: 96 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 48 },
          { name: 'Week 2', value: 54 },
          { name: 'Week 3', value: 61 },
          { name: 'Week 4', value: 68 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 87 },
          { name: 'Week 8', value: 92 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 88 },
          { name: 'Week 2', value: 90 },
          { name: 'Week 3', value: 92 },
          { name: 'Week 4', value: 93 },
          { name: 'Week 5', value: 94 },
          { name: 'Week 6', value: 95 },
          { name: 'Week 7', value: 95 },
          { name: 'Week 8', value: 95 },
        ],
      },
    ],
    insightText: '환절기 장벽 강화 니즈로 판테놀 고농축 크림의 리뷰 긍정 반응 95% 기록.',
    combinationReason: '판테놀의 진정 효과와 크림 제형의 보습력이 배리어 리페어에 최적화되었습니다. SNS(92%), 리테일(88%), 리뷰(95%)에서 모두 급상승세를 보이며 즉시 활용 가능한 트렌드입니다.',
    actionGuide: '🚀 Rising 단계: 테스트 제품이나 파일럿 기획에 적합. 신제품 라인업에 빠르게 반영하여 시장 반응을 확인할 수 있습니다.',
    metrics: [
      { label: '성장률', value: 28.7, unit: '%', change: 7.3, trend: 'up' },
      { label: 'SNS 언급', value: 96, unit: '%', change: 10.2, trend: 'up' },
      { label: '판매 증가', value: 24.5, unit: '%', change: 5.8, trend: 'up' },
      { label: '긍정 리뷰', value: 95, unit: '%', change: 2.5, trend: 'up' },
      { label: '시장 점유', value: 14.8, unit: '%', change: 1.9, trend: 'up' },
      { label: '인지도', value: 72.3, unit: '%', change: 6.2, trend: 'up' },
    ],
  },
  {
    rank: 6,
    category: 'Menscare',
    combination: '시카 + 올인원 + 진정',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 72 },
          { name: 'Week 2', value: 74 },
          { name: 'Week 3', value: 73 },
          { name: 'Week 4', value: 75 },
          { name: 'Week 5', value: 76 },
          { name: 'Week 6', value: 75 },
          { name: 'Week 7', value: 77 },
          { name: 'Week 8', value: 78 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 68 },
          { name: 'Week 2', value: 70 },
          { name: 'Week 3', value: 69 },
          { name: 'Week 4', value: 71 },
          { name: 'Week 5', value: 72 },
          { name: 'Week 6', value: 71 },
          { name: 'Week 7', value: 73 },
          { name: 'Week 8', value: 74 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 75 },
          { name: 'Week 2', value: 77 },
          { name: 'Week 3', value: 78 },
          { name: 'Week 4', value: 79 },
          { name: 'Week 5', value: 80 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 82 },
          { name: 'Week 8', value: 83 },
        ],
      },
    ],
    insightText: '면도 후 자극 진정을 원하는 남성 고객층에서 시카 올인원 제품 재구매율 상승.',
  },
  {
    rank: 7,
    category: 'Haircare',
    combination: '비오틴 + 샴푸 + 탈모 방지',
    status: '📉 Cooling',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 65 },
          { name: 'Week 2', value: 62 },
          { name: 'Week 3', value: 59 },
          { name: 'Week 4', value: 56 },
          { name: 'Week 5', value: 54 },
          { name: 'Week 6', value: 52 },
          { name: 'Week 7', value: 50 },
          { name: 'Week 8', value: 48 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 58 },
          { name: 'Week 2', value: 56 },
          { name: 'Week 3', value: 54 },
          { name: 'Week 4', value: 52 },
          { name: 'Week 5', value: 51 },
          { name: 'Week 6', value: 50 },
          { name: 'Week 7', value: 49 },
          { name: 'Week 8', value: 48 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 72 },
          { name: 'Week 2', value: 73 },
          { name: 'Week 3', value: 74 },
          { name: 'Week 4', value: 75 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 76 },
          { name: 'Week 7', value: 76 },
          { name: 'Week 8', value: 77 },
        ],
      },
    ],
    insightText: '탈모 샴푸 시장은 포화 상태이나, 비오틴 고함량 제품은 여전히 상위권 유지.',
  },
];

// 해외 트렌드 데이터
export const trendDataOverseas: TrendItem[] = [
  {
    rank: 1,
    category: 'Skincare',
    combination: '레티놀 + 세럼 + 안티에이징',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 52 },
          { name: 'Week 2', value: 58 },
          { name: 'Week 3', value: 65 },
          { name: 'Week 4', value: 72 },
          { name: 'Week 5', value: 79 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 91 },
          { name: 'Week 8', value: 96 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 48 },
          { name: 'Week 2', value: 55 },
          { name: 'Week 3', value: 62 },
          { name: 'Week 4', value: 69 },
          { name: 'Week 5', value: 76 },
          { name: 'Week 6', value: 82 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 93 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 50 },
          { name: 'Week 2', value: 57 },
          { name: 'Week 3', value: 64 },
          { name: 'Week 4', value: 71 },
          { name: 'Week 5', value: 78 },
          { name: 'Week 6', value: 84 },
          { name: 'Week 7', value: 90 },
          { name: 'Week 8', value: 95 },
        ],
      },
    ],
    insightText: 'Retinol and serum combination shows 8-week continuous growth in anti-aging market.',
    metrics: [
      { label: 'Growth Rate', value: 35.2, unit: '%', change: 9.1, trend: 'up' },
      { label: 'SNS Mentions', value: 96, unit: '%', change: 13.5, trend: 'up' },
      { label: 'Sales Growth', value: 30.8, unit: '%', change: 7.2, trend: 'up' },
      { label: 'Positive Reviews', value: 95, unit: '%', change: 4.2, trend: 'up' },
      { label: 'Market Share', value: 22.1, unit: '%', change: 3.5, trend: 'up' },
      { label: 'Awareness', value: 89.3, unit: '%', change: 11.2, trend: 'up' },
    ],
  },
  {
    rank: 2,
    category: 'Suncare',
    combination: '아연옥사이드 + 선크림 + 끈적임 없는',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 88 },
          { name: 'Week 2', value: 90 },
          { name: 'Week 3', value: 89 },
          { name: 'Week 4', value: 91 },
          { name: 'Week 5', value: 92 },
          { name: 'Week 6', value: 90 },
          { name: 'Week 7', value: 91 },
          { name: 'Week 8', value: 93 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 94 },
          { name: 'Week 2', value: 96 },
          { name: 'Week 3', value: 95 },
          { name: 'Week 4', value: 97 },
          { name: 'Week 5', value: 98 },
          { name: 'Week 6', value: 97 },
          { name: 'Week 7', value: 98 },
          { name: 'Week 8', value: 99 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 90 },
          { name: 'Week 2', value: 91 },
          { name: 'Week 3', value: 92 },
          { name: 'Week 4', value: 93 },
          { name: 'Week 5', value: 94 },
          { name: 'Week 6', value: 93 },
          { name: 'Week 7', value: 94 },
          { name: 'Week 8', value: 95 },
        ],
      },
    ],
    insightText: 'Non-greasy mineral sunscreen maintains #1 retail ranking due to increased outdoor activities.',
    metrics: [
      { label: 'Growth Rate', value: 5.8, unit: '%', change: 1.2, trend: 'up' },
      { label: 'SNS Mentions', value: 93, unit: '%', change: 2.5, trend: 'stable' },
      { label: 'Sales Growth', value: 4.1, unit: '%', change: 0.5, trend: 'up' },
      { label: 'Positive Reviews', value: 95, unit: '%', change: 0.8, trend: 'stable' },
      { label: 'Market Share', value: 28.5, unit: '%', change: 0.3, trend: 'stable' },
      { label: 'Awareness', value: 85.2, unit: '%', change: 1.8, trend: 'up' },
    ],
  },
  {
    rank: 3,
    category: 'Skincare',
    combination: '나이아신아마이드 + 에센스 + 미백',
    status: '🌱 Early Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 28 },
          { name: 'Week 2', value: 35 },
          { name: 'Week 3', value: 44 },
          { name: 'Week 4', value: 55 },
          { name: 'Week 5', value: 68 },
          { name: 'Week 6', value: 78 },
          { name: 'Week 7', value: 86 },
          { name: 'Week 8', value: 92 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 25 },
          { name: 'Week 2', value: 32 },
          { name: 'Week 3', value: 41 },
          { name: 'Week 4', value: 52 },
          { name: 'Week 5', value: 65 },
          { name: 'Week 6', value: 75 },
          { name: 'Week 7', value: 83 },
          { name: 'Week 8', value: 89 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 30 },
          { name: 'Week 2', value: 38 },
          { name: 'Week 3', value: 47 },
          { name: 'Week 4', value: 58 },
          { name: 'Week 5', value: 71 },
          { name: 'Week 6', value: 80 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 93 },
        ],
      },
    ],
    insightText: 'Niacinamide essence shows rapid growth in brightening category for early trend.',
    metrics: [
      { label: 'Growth Rate', value: 52.3, unit: '%', change: 18.5, trend: 'up' },
      { label: 'SNS Mentions', value: 92, unit: '%', change: 20.2, trend: 'up' },
      { label: 'Sales Growth', value: 41.5, unit: '%', change: 15.3, trend: 'up' },
      { label: 'Positive Reviews', value: 93, unit: '%', change: 7.8, trend: 'up' },
      { label: 'Market Share', value: 11.2, unit: '%', change: 2.8, trend: 'up' },
      { label: 'Awareness', value: 58.7, unit: '%', change: 15.2, trend: 'up' },
    ],
  },
  {
    rank: 4,
    category: 'Makeup',
    combination: '히알루론산 + 파운데이션 + 광채',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 82 },
          { name: 'Week 2', value: 84 },
          { name: 'Week 3', value: 83 },
          { name: 'Week 4', value: 85 },
          { name: 'Week 5', value: 86 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 87 },
          { name: 'Week 8', value: 88 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 78 },
          { name: 'Week 2', value: 80 },
          { name: 'Week 3', value: 79 },
          { name: 'Week 4', value: 81 },
          { name: 'Week 5', value: 82 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 83 },
          { name: 'Week 8', value: 84 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 85 },
          { name: 'Week 2', value: 87 },
          { name: 'Week 3', value: 86 },
          { name: 'Week 4', value: 88 },
          { name: 'Week 5', value: 89 },
          { name: 'Week 6', value: 88 },
          { name: 'Week 7', value: 90 },
          { name: 'Week 8', value: 91 },
        ],
      },
    ],
    insightText: 'Hyaluronic acid foundation maintains stable popularity for dry skin target.',
    metrics: [
      { label: 'Growth Rate', value: 4.2, unit: '%', change: 0.7, trend: 'stable' },
      { label: 'SNS Mentions', value: 88, unit: '%', change: 1.5, trend: 'stable' },
      { label: 'Sales Growth', value: 2.5, unit: '%', change: 0.4, trend: 'stable' },
      { label: 'Positive Reviews', value: 91, unit: '%', change: 1.0, trend: 'stable' },
      { label: 'Market Share', value: 18.3, unit: '%', change: 0.2, trend: 'stable' },
      { label: 'Awareness', value: 81.5, unit: '%', change: 2.1, trend: 'up' },
    ],
  },
  {
    rank: 5,
    category: 'Skincare',
    combination: '펩타이드 + 모이스처라이저 + 안티에이징',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 58 },
          { name: 'Week 2', value: 64 },
          { name: 'Week 3', value: 71 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 84 },
          { name: 'Week 6', value: 90 },
          { name: 'Week 7', value: 94 },
          { name: 'Week 8', value: 97 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 54 },
          { name: 'Week 2', value: 60 },
          { name: 'Week 3', value: 67 },
          { name: 'Week 4', value: 74 },
          { name: 'Week 5', value: 80 },
          { name: 'Week 6', value: 86 },
          { name: 'Week 7', value: 91 },
          { name: 'Week 8', value: 95 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 92 },
          { name: 'Week 2', value: 93 },
          { name: 'Week 3', value: 94 },
          { name: 'Week 4', value: 95 },
          { name: 'Week 5', value: 96 },
          { name: 'Week 6', value: 96 },
          { name: 'Week 7', value: 97 },
          { name: 'Week 8', value: 97 },
        ],
      },
    ],
    insightText: 'Peptide moisturizer shows strong growth with 97% positive review rate.',
    metrics: [
      { label: 'Growth Rate', value: 31.5, unit: '%', change: 8.7, trend: 'up' },
      { label: 'SNS Mentions', value: 97, unit: '%', change: 11.8, trend: 'up' },
      { label: 'Sales Growth', value: 27.2, unit: '%', change: 6.5, trend: 'up' },
      { label: 'Positive Reviews', value: 97, unit: '%', change: 3.2, trend: 'up' },
      { label: 'Market Share', value: 16.8, unit: '%', change: 2.1, trend: 'up' },
      { label: 'Awareness', value: 76.4, unit: '%', change: 7.8, trend: 'up' },
    ],
  },
  {
    rank: 6,
    category: 'Skincare',
    combination: '비타민C + 세럼 + 미백',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 75 },
          { name: 'Week 2', value: 77 },
          { name: 'Week 3', value: 76 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 79 },
          { name: 'Week 6', value: 78 },
          { name: 'Week 7', value: 80 },
          { name: 'Week 8', value: 81 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 71 },
          { name: 'Week 2', value: 73 },
          { name: 'Week 3', value: 72 },
          { name: 'Week 4', value: 74 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 74 },
          { name: 'Week 7', value: 76 },
          { name: 'Week 8', value: 77 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 78 },
          { name: 'Week 2', value: 80 },
          { name: 'Week 3', value: 81 },
          { name: 'Week 4', value: 82 },
          { name: 'Week 5', value: 83 },
          { name: 'Week 6', value: 84 },
          { name: 'Week 7', value: 85 },
          { name: 'Week 8', value: 86 },
        ],
      },
    ],
    insightText: 'Vitamin C serum maintains stable position in brightening category.',
    metrics: [
      { label: 'Growth Rate', value: 3.5, unit: '%', change: 0.6, trend: 'stable' },
      { label: 'SNS Mentions', value: 81, unit: '%', change: 1.2, trend: 'stable' },
      { label: 'Sales Growth', value: 2.1, unit: '%', change: 0.3, trend: 'stable' },
      { label: 'Positive Reviews', value: 86, unit: '%', change: 0.9, trend: 'stable' },
      { label: 'Market Share', value: 14.2, unit: '%', change: 0.1, trend: 'stable' },
      { label: 'Awareness', value: 79.8, unit: '%', change: 1.5, trend: 'up' },
    ],
  },
  {
    rank: 7,
    category: 'Skincare',
    combination: '세라마이드 + 리페어 + 장벽 강화',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 55 },
          { name: 'Week 2', value: 62 },
          { name: 'Week 3', value: 70 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 85 },
          { name: 'Week 6', value: 91 },
          { name: 'Week 7', value: 95 },
          { name: 'Week 8', value: 98 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 52 },
          { name: 'Week 2', value: 59 },
          { name: 'Week 3', value: 67 },
          { name: 'Week 4', value: 75 },
          { name: 'Week 5', value: 82 },
          { name: 'Week 6', value: 88 },
          { name: 'Week 7', value: 93 },
          { name: 'Week 8', value: 96 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 90 },
          { name: 'Week 2', value: 92 },
          { name: 'Week 3', value: 94 },
          { name: 'Week 4', value: 95 },
          { name: 'Week 5', value: 96 },
          { name: 'Week 6', value: 97 },
          { name: 'Week 7', value: 97 },
          { name: 'Week 8', value: 98 },
        ],
      },
    ],
    insightText: 'Ceramide barrier repair products show strong growth with seasonal demand.',
    metrics: [
      { label: 'Growth Rate', value: 33.8, unit: '%', change: 9.2, trend: 'up' },
      { label: 'SNS Mentions', value: 98, unit: '%', change: 12.5, trend: 'up' },
      { label: 'Sales Growth', value: 29.5, unit: '%', change: 7.1, trend: 'up' },
      { label: 'Positive Reviews', value: 98, unit: '%', change: 4.5, trend: 'up' },
      { label: 'Market Share', value: 17.5, unit: '%', change: 2.3, trend: 'up' },
      { label: 'Awareness', value: 78.2, unit: '%', change: 8.5, trend: 'up' },
    ],
  },
];

// Single 키워드 데이터 (핵심 키워드)
export const singleKeywordData: TrendItem[] = [
  {
    rank: 1,
    category: 'Ingredient',
    combination: '레티놀',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 55 },
          { name: 'Week 2', value: 62 },
          { name: 'Week 3', value: 70 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 85 },
          { name: 'Week 6', value: 92 },
          { name: 'Week 7', value: 96 },
          { name: 'Week 8', value: 98 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 48 },
          { name: 'Week 2', value: 55 },
          { name: 'Week 3', value: 63 },
          { name: 'Week 4', value: 71 },
          { name: 'Week 5', value: 78 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 91 },
          { name: 'Week 8', value: 95 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 52 },
          { name: 'Week 2', value: 59 },
          { name: 'Week 3', value: 67 },
          { name: 'Week 4', value: 75 },
          { name: 'Week 5', value: 82 },
          { name: 'Week 6', value: 89 },
          { name: 'Week 7', value: 94 },
          { name: 'Week 8', value: 97 },
        ],
      },
    ],
    insightText: '레티놀 단일 성분이 2030 모공 고민 고객층에서 8주 연속 급상승 중입니다.',
    metrics: [
      { label: '성장률', value: 35.8, unit: '%', change: 9.5, trend: 'up' },
      { label: 'SNS 언급', value: 98, unit: '%', change: 15.2, trend: 'up' },
      { label: '판매 증가', value: 30.2, unit: '%', change: 7.8, trend: 'up' },
      { label: '긍정 리뷰', value: 97, unit: '%', change: 4.5, trend: 'up' },
      { label: '시장 점유', value: 22.3, unit: '%', change: 3.1, trend: 'up' },
      { label: '인지도', value: 88.5, unit: '%', change: 10.2, trend: 'up' },
    ],
  },
  {
    rank: 2,
    category: 'Ingredient',
    combination: '판테놀',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 45 },
          { name: 'Week 2', value: 52 },
          { name: 'Week 3', value: 60 },
          { name: 'Week 4', value: 68 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 82 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 93 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 42 },
          { name: 'Week 2', value: 49 },
          { name: 'Week 3', value: 57 },
          { name: 'Week 4', value: 65 },
          { name: 'Week 5', value: 72 },
          { name: 'Week 6', value: 79 },
          { name: 'Week 7', value: 85 },
          { name: 'Week 8', value: 90 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 88 },
          { name: 'Week 2', value: 90 },
          { name: 'Week 3', value: 92 },
          { name: 'Week 4', value: 93 },
          { name: 'Week 5', value: 94 },
          { name: 'Week 6', value: 95 },
          { name: 'Week 7', value: 95 },
          { name: 'Week 8', value: 96 },
        ],
      },
    ],
    insightText: '환절기 장벽 강화 니즈로 판테놀 단일 성분의 리뷰 긍정 반응 96% 기록.',
    metrics: [
      { label: '성장률', value: 26.4, unit: '%', change: 6.8, trend: 'up' },
      { label: 'SNS 언급', value: 93, unit: '%', change: 9.5, trend: 'up' },
      { label: '판매 증가', value: 22.7, unit: '%', change: 5.2, trend: 'up' },
      { label: '긍정 리뷰', value: 96, unit: '%', change: 3.1, trend: 'up' },
      { label: '시장 점유', value: 16.5, unit: '%', change: 2.3, trend: 'up' },
      { label: '인지도', value: 74.8, unit: '%', change: 7.5, trend: 'up' },
    ],
  },
  {
    rank: 3,
    category: 'Formula',
    combination: '앰플',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 78 },
          { name: 'Week 2', value: 80 },
          { name: 'Week 3', value: 79 },
          { name: 'Week 4', value: 81 },
          { name: 'Week 5', value: 82 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 83 },
          { name: 'Week 8', value: 84 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 75 },
          { name: 'Week 2', value: 77 },
          { name: 'Week 3', value: 76 },
          { name: 'Week 4', value: 78 },
          { name: 'Week 5', value: 79 },
          { name: 'Week 6', value: 78 },
          { name: 'Week 7', value: 80 },
          { name: 'Week 8', value: 81 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 82 },
          { name: 'Week 2', value: 84 },
          { name: 'Week 3', value: 83 },
          { name: 'Week 4', value: 85 },
          { name: 'Week 5', value: 86 },
          { name: 'Week 6', value: 85 },
          { name: 'Week 7', value: 87 },
          { name: 'Week 8', value: 88 },
        ],
      },
    ],
    insightText: '앰플 제형이 고농축 성분 전달 수단으로 안정적인 인기 유지 중.',
  },
  {
    rank: 4,
    category: 'Ingredient',
    combination: '시카',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 72 },
          { name: 'Week 2', value: 74 },
          { name: 'Week 3', value: 73 },
          { name: 'Week 4', value: 75 },
          { name: 'Week 5', value: 76 },
          { name: 'Week 6', value: 75 },
          { name: 'Week 7', value: 77 },
          { name: 'Week 8', value: 78 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 68 },
          { name: 'Week 2', value: 70 },
          { name: 'Week 3', value: 69 },
          { name: 'Week 4', value: 71 },
          { name: 'Week 5', value: 72 },
          { name: 'Week 6', value: 71 },
          { name: 'Week 7', value: 73 },
          { name: 'Week 8', value: 74 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 75 },
          { name: 'Week 2', value: 77 },
          { name: 'Week 3', value: 78 },
          { name: 'Week 4', value: 79 },
          { name: 'Week 5', value: 80 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 82 },
          { name: 'Week 8', value: 83 },
        ],
      },
    ],
    insightText: '시카 성분이 자극 진정 니즈로 남성 고객층에서 안정적인 인기 유지.',
  },
  {
    rank: 5,
    category: 'Formula',
    combination: '크림',
    status: '📈 Growing Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 85 },
          { name: 'Week 2', value: 87 },
          { name: 'Week 3', value: 86 },
          { name: 'Week 4', value: 88 },
          { name: 'Week 5', value: 89 },
          { name: 'Week 6', value: 87 },
          { name: 'Week 7', value: 88 },
          { name: 'Week 8', value: 90 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 92 },
          { name: 'Week 2', value: 94 },
          { name: 'Week 3', value: 93 },
          { name: 'Week 4', value: 95 },
          { name: 'Week 5', value: 96 },
          { name: 'Week 6', value: 95 },
          { name: 'Week 7', value: 96 },
          { name: 'Week 8', value: 97 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 88 },
          { name: 'Week 2', value: 89 },
          { name: 'Week 3', value: 90 },
          { name: 'Week 4', value: 91 },
          { name: 'Week 5', value: 92 },
          { name: 'Week 6', value: 91 },
          { name: 'Week 7', value: 92 },
          { name: 'Week 8', value: 93 },
        ],
      },
    ],
    insightText: '크림 제형이 보습과 장벽 강화 목적으로 안정적인 시장 점유율 유지.',
  },
  {
    rank: 6,
    category: 'Effect',
    combination: '모공 케어',
    status: '🌱 Early Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 25 },
          { name: 'Week 2', value: 32 },
          { name: 'Week 3', value: 41 },
          { name: 'Week 4', value: 52 },
          { name: 'Week 5', value: 63 },
          { name: 'Week 6', value: 72 },
          { name: 'Week 7', value: 80 },
          { name: 'Week 8', value: 87 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 22 },
          { name: 'Week 2', value: 28 },
          { name: 'Week 3', value: 36 },
          { name: 'Week 4', value: 46 },
          { name: 'Week 5', value: 58 },
          { name: 'Week 6', value: 68 },
          { name: 'Week 7', value: 76 },
          { name: 'Week 8', value: 83 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 28 },
          { name: 'Week 2', value: 35 },
          { name: 'Week 3', value: 43 },
          { name: 'Week 4', value: 54 },
          { name: 'Week 5', value: 65 },
          { name: 'Week 6', value: 74 },
          { name: 'Week 7', value: 82 },
          { name: 'Week 8', value: 89 },
        ],
      },
    ],
    insightText: '모공 케어 효과가 2030 세대에서 급상승 중인 초기 트렌드.',
  },
  {
    rank: 7,
    category: 'Effect',
    combination: '장벽 강화',
    status: '🚀 Actionable Trend',
    signals: [
      {
        type: 'SNS',
        data: [
          { name: 'Week 1', value: 48 },
          { name: 'Week 2', value: 55 },
          { name: 'Week 3', value: 63 },
          { name: 'Week 4', value: 71 },
          { name: 'Week 5', value: 78 },
          { name: 'Week 6', value: 84 },
          { name: 'Week 7', value: 89 },
          { name: 'Week 8', value: 93 },
        ],
      },
      {
        type: 'Retail',
        data: [
          { name: 'Week 1', value: 45 },
          { name: 'Week 2', value: 52 },
          { name: 'Week 3', value: 60 },
          { name: 'Week 4', value: 68 },
          { name: 'Week 5', value: 75 },
          { name: 'Week 6', value: 81 },
          { name: 'Week 7', value: 86 },
          { name: 'Week 8', value: 90 },
        ],
      },
      {
        type: 'Review',
        data: [
          { name: 'Week 1', value: 85 },
          { name: 'Week 2', value: 87 },
          { name: 'Week 3', value: 89 },
          { name: 'Week 4', value: 91 },
          { name: 'Week 5', value: 92 },
          { name: 'Week 6', value: 93 },
          { name: 'Week 7', value: 94 },
          { name: 'Week 8', value: 95 },
        ],
      },
    ],
    insightText: '환절기와 환경 변화로 인한 장벽 강화 니즈가 지속적으로 상승 중.',
  },
];

// 국내 Bubble Chart 데이터
export const bubbleDataDomestic: BubbleItem[] = [
  // 성분
  { id: '1', name: '레티놀', type: 'ingredient', x: 20, y: 30, size: 85, value: 95, status: '🚀 Actionable Trend' },
  { id: '2', name: '판테놀', type: 'ingredient', x: 35, y: 45, size: 75, value: 90, status: '🚀 Actionable Trend' },
  { id: '3', name: '시카', type: 'ingredient', x: 50, y: 25, size: 65, value: 78, status: '🌱 Early Trend' },
  { id: '4', name: '히알루론산', type: 'ingredient', x: 25, y: 60, size: 70, value: 82, status: '📈 Growing Trend' },
  { id: '5', name: '나이아신아마이드', type: 'ingredient', x: 60, y: 40, size: 60, value: 75, status: '🌱 Early Trend' },
  // 제형
  { id: '6', name: '앰플', type: 'formula', x: 70, y: 35, size: 80, value: 88, status: '📈 Growing Trend' },
  { id: '7', name: '크림', type: 'formula', x: 80, y: 55, size: 90, value: 97, status: '🚀 Actionable Trend' },
  { id: '8', name: '선스틱', type: 'formula', x: 65, y: 70, size: 55, value: 68, status: '🌱 Early Trend' },
  { id: '9', name: '쿠션', type: 'formula', x: 45, y: 75, size: 65, value: 81, status: '📈 Growing Trend' },
  // 효과
  { id: '10', name: '모공 케어', type: 'effect', x: 15, y: 50, size: 70, value: 87, status: '📈 Growing Trend' },
  { id: '11', name: '장벽 강화', type: 'effect', x: 40, y: 65, size: 75, value: 93, status: '🚀 Actionable Trend' },
  { id: '12', name: '진정', type: 'effect', x: 55, y: 50, size: 60, value: 78, status: '🌱 Early Trend' },
  { id: '13', name: '광채', type: 'effect', x: 30, y: 80, size: 55, value: 72, status: '🌱 Early Trend' },
];

// 해외 Bubble Chart 데이터
export const bubbleDataOverseas: BubbleItem[] = [
  // 성분
  { id: 'ov1', name: 'Retinol', type: 'ingredient', x: 25, y: 35, size: 90, value: 98, status: '🚀 Actionable Trend' },
  { id: 'ov2', name: 'Niacinamide', type: 'ingredient', x: 40, y: 50, size: 85, value: 92, status: '🚀 Actionable Trend' },
  { id: 'ov3', name: 'Hyaluronic Acid', type: 'ingredient', x: 55, y: 30, size: 88, value: 95, status: '🚀 Actionable Trend' },
  { id: 'ov4', name: 'Vitamin C', type: 'ingredient', x: 30, y: 65, size: 75, value: 88, status: '📈 Growing Trend' },
  { id: 'ov5', name: 'Peptide', type: 'ingredient', x: 65, y: 45, size: 70, value: 82, status: '📈 Growing Trend' },
  // 제형
  { id: 'ov6', name: 'Serum', type: 'formula', x: 75, y: 40, size: 85, value: 93, status: '🚀 Actionable Trend' },
  { id: 'ov7', name: 'Moisturizer', type: 'formula', x: 85, y: 60, size: 92, value: 96, status: '🚀 Actionable Trend' },
  { id: 'ov8', name: 'Sunscreen', type: 'formula', x: 70, y: 75, size: 80, value: 90, status: '🚀 Actionable Trend' },
  { id: 'ov9', name: 'Essence', type: 'formula', x: 50, y: 80, size: 72, value: 85, status: '📈 Growing Trend' },
  // 효과
  { id: 'ov10', name: 'Anti-aging', type: 'effect', x: 20, y: 55, size: 88, value: 94, status: '🚀 Actionable Trend' },
  { id: 'ov11', name: 'Brightening', type: 'effect', x: 45, y: 70, size: 82, value: 91, status: '🚀 Actionable Trend' },
  { id: 'ov12', name: 'Hydration', type: 'effect', x: 60, y: 55, size: 75, value: 87, status: '📈 Growing Trend' },
  { id: 'ov13', name: 'Repair', type: 'effect', x: 35, y: 85, size: 68, value: 80, status: '📈 Growing Trend' },
];

// 하위 호환성을 위한 기본 export
export const bubbleData = bubbleDataDomestic;

// SNS 플랫폼별 Top 성분 데이터
export interface SNSTopIngredient {
  platform: 'Instagram' | 'TikTok' | 'YouTube';
  ingredients: { name: string; value: number; change: number }[];
}

export const snsTopIngredients: SNSTopIngredient[] = [
  {
    platform: 'Instagram',
    ingredients: [
      { name: '레티놀', value: 95, change: 12 },
      { name: '히알루론산', value: 88, change: 8 },
      { name: '나이아신아마이드', value: 82, change: 5 },
      { name: '시카', value: 78, change: 3 },
      { name: '판테놀', value: 75, change: 10 },
    ],
  },
  {
    platform: 'TikTok',
    ingredients: [
      { name: '레티놀', value: 98, change: 15 },
      { name: '판테놀', value: 90, change: 12 },
      { name: '시카', value: 85, change: 8 },
      { name: '히알루론산', value: 80, change: 6 },
      { name: '나이아신아마이드', value: 72, change: 4 },
    ],
  },
  {
    platform: 'YouTube',
    ingredients: [
      { name: '히알루론산', value: 92, change: 7 },
      { name: '레티놀', value: 89, change: 10 },
      { name: '나이아신아마이드', value: 85, change: 6 },
      { name: '시카', value: 80, change: 5 },
      { name: '판테놀', value: 78, change: 9 },
    ],
  },
];

// 보조 지표 데이터
export interface TrendMetric {
  label: string;
  value: number;
  unit: string;
  change: number;
  trend: 'up' | 'down' | 'stable';
}

export const trendMetrics: TrendMetric[] = [
  { label: '전체 트렌드 성장률', value: 24.5, unit: '%', change: 5.2, trend: 'up' },
  { label: 'SNS 언급량 증가', value: 18.3, unit: '%', change: 3.1, trend: 'up' },
  { label: '리테일 판매 증가', value: 15.7, unit: '%', change: 2.8, trend: 'up' },
  { label: '긍정 리뷰 비율', value: 87.2, unit: '%', change: 1.5, trend: 'up' },
  { label: '시장 점유율', value: 12.4, unit: '%', change: -0.3, trend: 'down' },
  { label: '브랜드 인지도', value: 68.9, unit: '%', change: 4.2, trend: 'up' },
];

// 보고서 생성 함수 (선택된 항목 기반)
export const generateReport = (
  type: 'marketing' | 'npd' | 'overseas',
  selectedItem: BubbleItem | null,
  country: Country
): ReportResult => {
  const countryName = country === 'usa' ? '미국' : country === 'japan' ? '일본' : country === 'singapore' ? '싱가포르' : country === 'malaysia' ? '말레이시아' : country === 'indonesia' ? '인도네시아' : '국내';
  const itemName = selectedItem?.name || '선택된 트렌드';
  const typeName = selectedItem?.type === 'ingredient' ? '성분' : selectedItem?.type === 'formula' ? '제형' : '기능';
  const evidence = selectedItem?.evidence;
  
  if (!selectedItem) {
    // 선택된 항목이 없을 때 기본 보고서
    return {
      type,
      content: type === 'marketing' 
        ? '리더보드 항목을 선택한 후 보고서를 생성해주세요.'
        : type === 'npd'
        ? '리더보드 항목을 선택한 후 보고서를 생성해주세요.'
        : '리더보드 항목을 선택한 후 보고서를 생성해주세요.',
    };
  }
  
  if (type === 'marketing') {
    return {
      type: 'marketing',
      content: `# 마케팅 캠페인 전략 보고서

## 📊 트렌드 개요
**분석 대상**: ${itemName} (${typeName})
**분석 국가**: ${countryName}
${evidence ? `**현재 상태**: ${selectedItem?.status || 'Actionable Trend'}` : ''}

## 🎯 타겟 고객층 분석
${evidence ? `
- **주요 연령대**: 25-35세 (${Math.floor(evidence.numericalEvidence.marketShare * 0.8)}% 점유)
- **핵심 니즈**: ${selectedItem?.reviewKeywords?.positive[0]?.keyword || '효과적'} 제품에 대한 높은 관심
- **구매 패턴**: SNS 영향력 높음 (${evidence.numericalEvidence.snsMentions.toLocaleString()}건 언급)
` : `
- **주요 연령대**: 25-35세
- **핵심 니즈**: 고효능 ${typeName}에 대한 수요 증가
- **구매 패턴**: SNS 영향력 높음
`}

## 💡 핵심 메시지 전략
${selectedItem?.reviewKeywords ? `
### 긍정적 소구 포인트
${selectedItem.reviewKeywords.positive.slice(0, 3).map(k => `- "${k.keyword}" (${k.count}건 언급)`).join('\n')}

### 주의해야 할 부정 키워드
${selectedItem.reviewKeywords.negative.slice(0, 2).map(k => `- "${k.keyword}" (${k.count}건 언급) - 마케팅 시 회피 또는 대응 전략 필요`).join('\n')}
` : `
### 메시지 방향
- "빠른 효과"와 "피부 개선"을 강조
- 실제 사용자 경험 기반 스토리텔링
- 과학적 근거와 함께 제시
`}

## 📱 채널별 전략
### Instagram
- **콘텐츠 유형**: Before/After 사진, 사용법 튜토리얼
- **인플루언서 협업**: ${countryName} 내 ${typeName} 전문 뷰티 크리에이터
- **해시태그**: #${itemName.replace(/\s/g, '')} #${typeName}트렌드

### TikTok
- **콘텐츠 유형**: 짧은 사용 후기, 트렌드 설명 영상
- **챌린지**: "${itemName} 챌린지" 기획
- **타겟**: 20-30대 Z세대

### YouTube
- **콘텐츠 유형**: 상세 리뷰, 성분 분석, 비교 영상
- **협업**: 뷰티 전문 유튜버와 장기 파트너십

## 🎨 크리에이티브 방향
${selectedItem?.reviewKeywords?.positive[0] ? `
- **메인 메시지**: "${selectedItem.reviewKeywords.positive[0].keyword}"를 강조
- **비주얼**: 깔끔하고 과학적인 느낌의 이미지
- **톤앤매너**: 전문적이면서도 친근한 톤
` : `
- **메인 메시지**: "검증된 효과"와 "신뢰할 수 있는 선택"
- **비주얼**: 깔끔하고 과학적인 느낌의 이미지
- **톤앤매너**: 전문적이면서도 친근한 톤
`}

## 📈 예상 성과
${evidence ? `
- **SNS 도달률**: ${evidence.numericalEvidence.snsMentions.toLocaleString()}명 (현재 언급 기준)
- **예상 전환율**: ${Math.floor(evidence.numericalEvidence.growthRate * 0.3)}% (성장률 기반)
- **ROI 목표**: ${Math.floor(evidence.numericalEvidence.marketShare * 1.5)}% 시장 점유율 달성
` : `
- **SNS 도달률**: 높은 관심도 예상
- **예상 전환율**: 트렌드 상승세 기반 긍정적 전망
- **ROI 목표**: 시장 점유율 확대
`}

## ⚠️ 주의사항
${selectedItem?.reviewKeywords?.negative[0] ? `
- "${selectedItem.reviewKeywords.negative[0].keyword}" 관련 부정 피드백에 대한 대응 방안 준비
- 과장된 광고 문구 사용 지양
- 실제 사용자 리뷰 기반의 솔직한 커뮤니케이션
` : `
- 과장된 광고 문구 사용 지양
- 실제 사용자 리뷰 기반의 솔직한 커뮤니케이션
- 지속적인 모니터링 및 피드백 수집
`}

---
*본 보고서는 AI 기반 트렌드 분석 데이터를 활용하여 생성되었습니다.*
*생성일시: ${new Date().toLocaleString('ko-KR')}*
`,
    };
  } else if (type === 'npd') {
    return {
      type: 'npd',
      content: `# 신제품 기획(BM) 보고서

## 📊 트렌드 개요
**분석 대상**: ${itemName} (${typeName})
**분석 국가**: ${countryName}
${evidence ? `**현재 상태**: ${selectedItem?.status || 'Actionable Trend'}` : ''}

## 🧪 제품 컨셉 제안
${selectedItem?.type === 'ingredient' ? `
### 핵심 성분: ${itemName}
- **제형 제안**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('흡수') || k.keyword.includes('사용감')) ? '에센스/세럼 타입 (빠른 흡수)' : '앰플 타입 (고농도)'}
- **조합 제안**: ${selectedItem.reviewKeywords?.positive[0]?.keyword || '효과적'}과 함께 사용 시 시너지 효과
- **타겟 고객**: ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 0.8)}% 시장 점유` : '25-35세'} 고효능 제품 추구 고객
` : selectedItem?.type === 'formula' ? `
### 핵심 제형: ${itemName}
- **성분 제안**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('효과') || k.keyword.includes('개선')) ? '고효능 성분 조합' : '부드러운 성분 조합'}
- **텍스처**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('부드') || k.keyword.includes('촉촉')) ? '부드럽고 촉촉한' : '가벼운'} 사용감
- **타겟 고객**: ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 0.8)}% 시장 점유` : '25-35세'} 사용감 중시 고객
` : `
### 핵심 기능: ${itemName}
- **성분/제형 조합**: ${selectedItem.reviewKeywords?.positive[0]?.keyword || '효과적'} 효과를 극대화하는 조합
- **차별화 포인트**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('빠른') || k.keyword.includes('즉시')) ? '빠른 효과' : '지속적인 효과'}
- **타겟 고객**: ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 0.8)}% 시장 점유` : '25-35세'} 기능 중심 고객
`}

## 💎 USP (Unique Selling Point)
${selectedItem?.reviewKeywords?.positive[0] ? `
1. **"${selectedItem.reviewKeywords.positive[0].keyword}"** - ${selectedItem.reviewKeywords.positive[0].count}건의 리뷰에서 검증
2. **빠른 효과 체감** - ${evidence ? `${evidence.numericalEvidence.growthRate}%` : '높은'} 성장률로 증명된 트렌드
3. **${countryName} 시장 검증** - ${evidence ? `${evidence.numericalEvidence.reviewCount.toLocaleString()}건` : '다수의'} 리뷰로 신뢰도 확보
` : `
1. **검증된 트렌드** - ${evidence ? `${evidence.numericalEvidence.growthRate}%` : '높은'} 성장률
2. **시장 검증** - ${evidence ? `${evidence.numericalEvidence.reviewCount.toLocaleString()}건` : '다수의'} 리뷰
3. **${countryName} 시장 적합성** - 현지 소비자 니즈 반영
`}

## 📋 제품 사양 제안
### 기본 스펙
- **용량**: ${selectedItem?.type === 'formula' ? '50ml / 100ml (2가지 옵션)' : '30ml / 50ml (2가지 옵션)'}
- **가격대**: ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 2)}만원` : '중가격'}대 (${countryName} 시장 기준)
- **포장**: ${selectedItem?.reviewKeywords?.positive.find(k => k.keyword.includes('가성비')) ? '심플하고 실용적인' : '프리미엄한'} 디자인

### 성분/제형 상세
${selectedItem?.type === 'ingredient' ? `
- **주성분**: ${itemName} ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 0.5)}%` : '고농도'} 함유
- **보조 성분**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('부드') || k.keyword.includes('진정')) ? '진정 성분' : '보습 성분'} 조합
- **제형**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('흡수') || k.keyword.includes('가벼')) ? '가벼운 에센스 타입' : '농축 앰플 타입'}
` : selectedItem?.type === 'formula' ? `
- **제형**: ${itemName}
- **주성분**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('효과') || k.keyword.includes('개선')) ? '고효능 성분' : '부드러운 성분'} 조합
- **텍스처**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('부드') || k.keyword.includes('촉촉')) ? '부드럽고 촉촉한' : '가벼운'} 사용감
` : `
- **핵심 기능**: ${itemName}
- **구현 방식**: ${selectedItem.reviewKeywords?.positive.find(k => k.keyword.includes('빠른') || k.keyword.includes('즉시')) ? '즉시 효과 + 장기 개선' : '지속적 개선'} 이중 전략
- **차별화**: ${selectedItem.reviewKeywords?.positive[0]?.keyword || '효과적'} 효과 강조
`}

## 🎯 타겟 고객 프로필
${evidence ? `
- **주요 연령대**: 25-35세 (${Math.floor(evidence.numericalEvidence.marketShare * 0.8)}%)
- **구매력**: ${Math.floor(evidence.numericalEvidence.marketShare * 1.2)}만원 이상 제품 구매 가능
- **소비 패턴**: SNS 영향력 높음, 리뷰 기반 구매 결정
- **핵심 니즈**: ${selectedItem?.reviewKeywords?.positive[0]?.keyword || '효과적'} 제품 추구
` : `
- **주요 연령대**: 25-35세
- **구매력**: 중가격대 제품 구매 가능
- **소비 패턴**: SNS 영향력 높음, 리뷰 기반 구매 결정
- **핵심 니즈**: 고효능 ${typeName} 추구
`}

## 📊 시장 기회 분석
${evidence ? `
- **시장 점유율**: 현재 ${evidence.numericalEvidence.marketShare}% (성장 가능성 높음)
- **성장률**: 전월 대비 ${evidence.numericalEvidence.growthRate}% 증가
- **경쟁 강도**: ${evidence.numericalEvidence.growthRate > 30 ? '높음 (빠른 진입 필요)' : '중간 (차별화 기회)'}
- **시장 규모**: ${evidence.numericalEvidence.snsMentions.toLocaleString()}건의 SNS 언급 = 높은 관심도
` : `
- **시장 점유율**: 성장 가능성 높음
- **성장률**: 급상승 중
- **경쟁 강도**: 차별화 기회 존재
- **시장 규모**: 높은 관심도
`}

## ⚠️ 리스크 및 대응 방안
${selectedItem?.reviewKeywords?.negative[0] ? `
### 주요 리스크
1. **"${selectedItem.reviewKeywords.negative[0].keyword}"** 관련 부정 피드백 (${selectedItem.reviewKeywords.negative[0].count}건)
   - 대응: 제품 개발 시 해당 이슈 해결에 집중
2. **가격 민감도**: ${selectedItem.reviewKeywords.negative.find(k => k.keyword.includes('가격')) ? '일부 고객의 가격 부담' : '중가격대 적정성 유지'}
   - 대응: 가성비 강조 및 다양한 용량 옵션 제공
3. **경쟁 제품**: 유사 제품 증가 가능성
   - 대응: 차별화된 USP 강조 및 조기 시장 진입
` : `
### 주요 리스크
1. **경쟁 제품**: 유사 제품 증가 가능성
   - 대응: 차별화된 USP 강조 및 조기 시장 진입
2. **시장 변동성**: 트렌드 변화 가능성
   - 대응: 지속적인 모니터링 및 유연한 전략 수립
`}

## 🚀 출시 전략
### Phase 1: 파일럿 출시 (1-2개월)
- 소규모 테스트 제품 출시
- 타겟 고객 그룹 피드백 수집
- ${selectedItem?.reviewKeywords?.positive[0]?.keyword || '효과'} 검증

### Phase 2: 정식 출시 (3-4개월)
- ${evidence ? `${evidence.numericalEvidence.marketShare}%` : '목표'} 시장 점유율 달성 목표
- SNS 마케팅 본격화
- 인플루언서 협업 확대

### Phase 3: 확장 (5-6개월)
- 제품 라인업 확장 검토
- ${countryName} 외 추가 국가 진출 검토
- 장기 브랜드 포지셔닝 강화

---
*본 보고서는 AI 기반 트렌드 분석 데이터를 활용하여 생성되었습니다.*
*생성일시: ${new Date().toLocaleString('ko-KR')}*
`,
    };
  } else {
    return {
      type: 'overseas',
      content: `# 해외 진출 전략 보고서

## 📊 트렌드 개요
**분석 대상**: ${itemName} (${typeName})
**분석 국가**: ${countryName}
${evidence ? `**현재 상태**: ${selectedItem?.status || 'Actionable Trend'}` : ''}

## 🌍 ${countryName} 시장 분석
${evidence ? `
### 시장 현황
- **시장 점유율**: ${evidence.numericalEvidence.marketShare}%
- **성장률**: 전월 대비 ${evidence.numericalEvidence.growthRate}% 증가
- **SNS 언급**: ${evidence.numericalEvidence.snsMentions.toLocaleString()}건
- **리뷰 개수**: ${evidence.numericalEvidence.reviewCount.toLocaleString()}건
- **시장 성숙도**: ${evidence.numericalEvidence.growthRate > 30 ? '초기 단계 (높은 성장 가능성)' : evidence.numericalEvidence.growthRate > 15 ? '성장 단계 (안정적 성장)' : '성숙 단계 (안정적 유지)'}
` : `
### 시장 현황
- **시장 성숙도**: 성장 단계
- **성장 가능성**: 높음
- **경쟁 환경**: 차별화 기회 존재
`}

## 🎯 진출 전략
### 1. 시장 진입 방식
${evidence ? `
- **추천 방식**: ${evidence.numericalEvidence.growthRate > 30 ? '조기 진입 (Early Entry) - 시장 선점 가능' : '안정적 진입 (Stable Entry) - 검증된 시장'}
- **진입 시점**: ${evidence.numericalEvidence.growthRate > 30 ? '즉시 (3개월 이내)' : '6개월 이내'}
- **투자 규모**: ${evidence.numericalEvidence.marketShare > 10 ? '대규모 투자 권장' : '중규모 투자로 시작'}
` : `
- **추천 방식**: 단계적 진입
- **진입 시점**: 6개월 이내
- **투자 규모**: 중규모 투자로 시작
`}

### 2. 채널 전략
${countryName === '일본' ? `
- **온라인**: Amazon Japan, 라쿠텐, Qoo10
- **오프라인**: 도쿄/오사카 버라이어티샵, 약국
- **전략**: 오프라인 진입 후 온라인 확장
` : countryName === '미국' ? `
- **온라인**: Amazon, Sephora, Ulta
- **오프라인**: Sephora, Ulta, 타겟
- **전략**: 온라인 중심, 오프라인은 선택적
` : countryName === '싱가포르' ? `
- **온라인**: Shopee, Lazada, Sephora SG
- **오프라인**: Sephora, Watsons, Guardian
- **전략**: 온라인/오프라인 병행
` : `
- **온라인**: 주요 이커머스 플랫폼
- **오프라인**: 주요 약국/화장품 매장
- **전략**: 온라인 중심 진입
`}

### 3. 제품 적응 전략
${selectedItem?.reviewKeywords ? `
#### 긍정적 반응 키워드 활용
${selectedItem.reviewKeywords.positive.slice(0, 3).map(k => `- "${k.keyword}" (${k.count}건) - 제품 포지셔닝에 반영`).join('\n')}

#### 부정적 피드백 대응
${selectedItem.reviewKeywords.negative.slice(0, 2).map(k => `- "${k.keyword}" (${k.count}건) - 제품 개발 시 개선 포인트`).join('\n')}
` : `
- **로컬라이제이션**: ${countryName} 소비자 선호도 반영
- **포장/라벨링**: 현지 언어 및 규정 준수
- **가격 전략**: 현지 시장 가격대 분석 후 결정
`}

## 💰 비즈니스 모델
### 가격 전략
${evidence ? `
- **권장 가격대**: ${Math.floor(evidence.numericalEvidence.marketShare * 2)}만원 (${countryName} 시장 기준)
- **경쟁력**: ${evidence.numericalEvidence.marketShare > 10 ? '높음 (시장 점유율 기반)' : '중간 (차별화 필요)'}
- **가격 유연성**: ${evidence.numericalEvidence.growthRate > 30 ? '프리미엄 포지셔닝 가능' : '가성비 포지셔닝 권장'}
` : `
- **권장 가격대**: 중가격대
- **경쟁력**: 차별화를 통한 경쟁력 확보
- **가격 유연성**: 시장 반응에 따라 조정
`}

### 수익 모델
- **초기 (1년)**: 브랜드 인지도 구축, 시장 점유율 확보
- **중기 (2-3년)**: ${evidence ? `${Math.floor(evidence.numericalEvidence.marketShare * 1.5)}%` : '목표'} 시장 점유율 달성
- **장기 (3년+)**: ${countryName} 시장 내 안정적 포지셔닝

## 📈 마케팅 전략
### 로컬 마케팅
${selectedItem?.reviewKeywords?.positive[0] ? `
- **핵심 메시지**: "${selectedItem.reviewKeywords.positive[0].keyword}" 강조
- **인플루언서**: ${countryName} 내 ${typeName} 전문 뷰티 크리에이터
- **이벤트**: "${itemName} 챌린지" 기획
` : `
- **핵심 메시지**: 검증된 효과와 신뢰성
- **인플루언서**: ${countryName} 내 뷰티 크리에이터
- **이벤트**: 트렌드 기반 마케팅 캠페인
`}

### 디지털 마케팅
- **SNS**: Instagram, TikTok, YouTube 현지 계정 운영
- **광고**: ${countryName} 주요 플랫폼 타겟팅 광고
- **콘텐츠**: 현지 언어로 제품 소개 및 사용법 콘텐츠

## ⚠️ 진출 장벽 및 대응
### 규제 및 인증
- **화장품 규제**: ${countryName} 화장품 규정 준수 필수
- **인증**: 필요한 인증 취득 (FDA, CE 등)
- **라벨링**: 현지 언어 및 필수 정보 표기

### 경쟁 환경
${evidence ? `
- **경쟁 강도**: ${evidence.numericalEvidence.growthRate > 30 ? '높음 (빠른 진입 필요)' : '중간 (차별화 기회)'}
- **차별화 전략**: ${selectedItem?.reviewKeywords?.positive[0]?.keyword || '효과적'} 효과 강조
- **가격 경쟁력**: ${evidence.numericalEvidence.marketShare > 10 ? '시장 점유율 기반 경쟁력' : '차별화를 통한 경쟁력'}
` : `
- **경쟁 강도**: 중간
- **차별화 전략**: 고효능 ${typeName} 강조
- **가격 경쟁력**: 가성비 중심
`}

### 문화적 적응
- **소비자 선호도**: ${selectedItem?.reviewKeywords?.positive[0]?.keyword || '효과'} 중심의 제품 선호
- **구매 패턴**: ${evidence ? `${evidence.numericalEvidence.snsMentions.toLocaleString()}건` : '높은'} SNS 영향력
- **마케팅 톤**: ${countryName} 문화에 맞는 커뮤니케이션

## 🎯 성공 지표 (KPI)
${evidence ? `
- **1년 목표 시장 점유율**: ${Math.floor(evidence.numericalEvidence.marketShare * 1.5)}%
- **SNS 언급 목표**: ${Math.floor(evidence.numericalEvidence.snsMentions * 1.3).toLocaleString()}건
- **리뷰 개수 목표**: ${Math.floor(evidence.numericalEvidence.reviewCount * 1.2).toLocaleString()}건
- **성장률 목표**: ${Math.floor(evidence.numericalEvidence.growthRate * 0.8)}% 유지
` : `
- **1년 목표 시장 점유율**: 10% 이상
- **SNS 언급 목표**: 지속적 증가
- **리뷰 개수 목표**: 긍정적 리뷰 비율 85% 이상
- **성장률 목표**: 안정적 성장 유지
`}

## 📅 로드맵
### 3개월: 시장 조사 및 준비
- 현지 파트너 탐색
- 규제 및 인증 준비
- 시장 테스트 계획 수립

### 6개월: 파일럿 출시
- 소규모 테스트 제품 출시
- 초기 고객 피드백 수집
- 마케팅 전략 조정

### 12개월: 정식 진입
- 본격적인 시장 진입
- 채널 확대
- 브랜드 인지도 구축

---
*본 보고서는 AI 기반 트렌드 분석 데이터를 활용하여 생성되었습니다.*
*생성일시: ${new Date().toLocaleString('ko-KR')}*
`,
    };
  }
};

// 보고서 결과 Mock 데이터 (하위 호환성)
export const reportResults = {
  marketing: {
    type: 'marketing' as const,
    content: '타겟: 2030 트러블 피부 / 키워드: "깐달걀 피부" / 채널: 틱톡 챌린지 추천',
  },
  npd: {
    type: 'npd' as const,
    content: '제안: 저자극 레티놀 시카 앰플 / 소구점: 밤낮없이 바르는 레티놀',
  },
  overseas: {
    type: 'overseas' as const,
    content: '추천 국가: 일본 / 이유: Qoo10 랭킹 급상승 중 / 전략: 오프라인 버라이어티샵 선점',
  },
};

