import { CountryLeaderboardData, MainCategory, ItemType, TrendLevel, LeaderboardItem, BubbleItem, TrendStatus, Country } from './mockData';
import { getTrendEvidence, getReviewKeywords } from './countryData';

// 국가별 리더보드 데이터
export const leaderboardData: Record<string, CountryLeaderboardData> = {
  USA: {
    "Skincare": {
      "Ingredients": {
        "Actionable": [
          { rank: 1, keyword: "Centella Asiatica", score: 98 },
          { rank: 2, keyword: "Snail Mucin", score: 96 },
          { rank: 3, keyword: "Retinol", score: 94 },
          { rank: 4, keyword: "Niacinamide", score: 92 },
          { rank: 5, keyword: "Ceramides", score: 91 }
        ],
        "Growing": [
          { rank: 1, keyword: "PDRN (Salmon DNA)", score: 85 },
          { rank: 2, keyword: "Spicule", score: 82 },
          { rank: 3, keyword: "Rice Extract", score: 79 },
          { rank: 4, keyword: "Ginseng", score: 76 },
          { rank: 5, keyword: "Kombucha", score: 74 }
        ],
        "Early": [
          { rank: 1, keyword: "Exosomes", score: 65 },
          { rank: 2, keyword: "Onion Extract", score: 62 },
          { rank: 3, keyword: "Succinic Acid", score: 58 },
          { rank: 4, keyword: "Mushroom Complex", score: 55 },
          { rank: 5, keyword: "Red Algae", score: 52 }
        ]
      },
      "Texture": {
        "Actionable": [
          { keyword: "Toner Pad", score: 95 },
          { keyword: "Serum", score: 93 },
          { keyword: "Lightweight Cream", score: 90 },
          { keyword: "Pimple Patch", score: 98 },
          { keyword: "Sheet Mask", score: 89 }
        ],
        "Growing": [
          { keyword: "Modeling Mask", score: 85 },
          { keyword: "Essence Mist", score: 80 },
          { keyword: "Stick Balm", score: 78 },
          { keyword: "Bubble Toner", score: 75 },
          { keyword: "Melting Balm", score: 72 }
        ],
        "Early": [
          { keyword: "Overnight Mask", score: 65 },
          { keyword: "Powder Wash", score: 60 },
          { keyword: "Jelly Mask", score: 58 },
          { keyword: "Oil-to-Foam", score: 55 },
          { keyword: "Freeze-dried", score: 52 }
        ]
      },
      "Effects": {
        "Actionable": [
          { keyword: "Barrier Repair", score: 99 },
          { keyword: "Glass Skin", score: 97 },
          { keyword: "Soothing", score: 95 },
          { keyword: "Hydrating", score: 92 },
          { keyword: "Glow", score: 91 }
        ],
        "Growing": [
          { keyword: "Slow Aging", score: 86 },
          { keyword: "Dark Spot", score: 83 },
          { keyword: "Redness Relief", score: 80 },
          { keyword: "Textured Skin", score: 77 },
          { keyword: "Plumping", score: 75 }
        ],
        "Early": [
          { keyword: "Neuro-Glow", score: 68 },
          { keyword: "Stress Care", score: 64 },
          { keyword: "Heat Aging", score: 60 },
          { keyword: "Microbiome Balance", score: 57 },
          { keyword: "Hormonal Acne", score: 54 }
        ]
      }
    },
    "Cleansing": {
      "Texture": {
        "Actionable": [
          { keyword: "Cleansing Balm", score: 96 },
          { keyword: "Micellar Water", score: 92 },
          { keyword: "Cleansing Oil", score: 90 },
          { keyword: "Gel Cleanser", score: 88 },
          { keyword: "Salicylic Wash", score: 85 }
        ],
        "Growing": [
          { keyword: "Oil-to-Milk", score: 82 },
          { keyword: "Powder Wash", score: 79 },
          { keyword: "Cleansing Stick", score: 75 },
          { keyword: "Wipe-off Milk", score: 72 },
          { keyword: "Clay Cleanser", score: 70 }
        ],
        "Early": [
          { keyword: "Melting Gel", score: 65 },
          { keyword: "Serum Cleanser", score: 62 },
          { keyword: "Carbonated Foam", score: 59 },
          { keyword: "Dry Oil", score: 55 },
          { keyword: "Solid Bar", score: 52 }
        ]
      }
    },
    "Sun Care": {
      "Effects": {
        "Actionable": [
          { keyword: "No White Cast", score: 98 },
          { keyword: "Reef Safe", score: 95 },
          { keyword: "Hydrating", score: 93 },
          { keyword: "Non-greasy", score: 90 },
          { keyword: "Glow Finish", score: 89 }
        ],
        "Growing": [
          { keyword: "Tinted Sunscreen", score: 85 },
          { keyword: "Sun Serum", score: 82 },
          { keyword: "Mineral Filter", score: 79 },
          { keyword: "Blue Light Block", score: 76 },
          { keyword: "Stick Format", score: 74 }
        ],
        "Early": [
          { keyword: "Scalp Sunscreen", score: 68 },
          { keyword: "Sun Mousse", score: 64 },
          { keyword: "Oral Sunblock", score: 55 },
          { keyword: "Wash-off Sun", score: 52 },
          { keyword: "Probiotic Sun", score: 50 }
        ]
      }
    },
    "Makeup": {
      "Texture": {
        "Actionable": [
          { keyword: "Liquid Blush", score: 95 },
          { keyword: "Lip Oil", score: 93 },
          { keyword: "Skin Tint", score: 90 },
          { keyword: "Setting Spray", score: 88 },
          { keyword: "Cream Bronzer", score: 85 }
        ],
        "Growing": [
          { keyword: "Cushion Foundation", score: 82 },
          { keyword: "Jelly Highlighter", score: 78 },
          { keyword: "Lip Stain", score: 75 },
          { keyword: "Brow Glue", score: 72 },
          { keyword: "Blurring Powder", score: 70 }
        ],
        "Early": [
          { keyword: "Peel-off Tint", score: 65 },
          { keyword: "Color Changing", score: 60 },
          { keyword: "Water Foundation", score: 58 },
          { keyword: "Stamp Blush", score: 55 },
          { keyword: "Magnetic Lashes", score: 52 }
        ]
      }
    },
    "Hair Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Bond Repair", score: 96 },
          { keyword: "Scalp Detox", score: 93 },
          { keyword: "Frizz Control", score: 90 },
          { keyword: "Heat Protection", score: 88 },
          { keyword: "Growth", score: 85 }
        ],
        "Growing": [
          { keyword: "Rosemary Oil", score: 82 },
          { keyword: "Rice Water", score: 79 },
          { keyword: "Clarifying", score: 76 },
          { keyword: "Glossing", score: 73 },
          { keyword: "Peptide Treatment", score: 70 }
        ],
        "Early": [
          { keyword: "Scalp Sunscreen", score: 65 },
          { keyword: "Hair Botox", score: 62 },
          { keyword: "Scalp Microneedling", score: 58 },
          { keyword: "Custom Color", score: 55 },
          { keyword: "Hard Water Detox", score: 52 }
        ]
      }
    },
    "Body Care": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Retinol", score: 94 },
          { keyword: "Glycolic Acid", score: 91 },
          { keyword: "Ceramides", score: 89 },
          { keyword: "Shea Butter", score: 87 },
          { keyword: "Salicylic Acid", score: 85 }
        ],
        "Growing": [
          { keyword: "Niacinamide", score: 82 },
          { keyword: "Hyaluronic Acid", score: 79 },
          { keyword: "Vitamin C", score: 76 },
          { keyword: "Caffeine", score: 73 },
          { keyword: "Collagen", score: 70 }
        ],
        "Early": [
          { keyword: "Bakuchiol", score: 65 },
          { keyword: "Magnesium", score: 62 },
          { keyword: "Kombucha", score: 59 },
          { keyword: "Pheromones", score: 55 },
          { keyword: "CBD", score: 52 }
        ]
      }
    },
    "Mens Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Beard Care", score: 93 },
          { keyword: "Simple Routine", score: 90 },
          { keyword: "Anti-fatigue", score: 87 },
          { keyword: "Acne Control", score: 85 },
          { keyword: "Oil Control", score: 83 }
        ],
        "Growing": [
          { keyword: "Concealer", score: 79 },
          { keyword: "Tinted Moisturizer", score: 76 },
          { keyword: "Dark Circles", score: 73 },
          { keyword: "Razor Bump", score: 70 },
          { keyword: "Hair Loss", score: 68 }
        ],
        "Early": [
          { keyword: "Nail Care", score: 60 },
          { keyword: "Intimate Wash", score: 58 },
          { keyword: "Makeup", score: 55 },
          { keyword: "Brow Grooming", score: 52 },
          { keyword: "Hand Mask", score: 50 }
        ]
      }
    }
  },
  Japan: {
    "Skincare": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Vitamin C", score: 99 },
          { keyword: "Retinol", score: 97 },
          { keyword: "Cica", score: 95 },
          { keyword: "Ceramides", score: 93 },
          { keyword: "Hyaluronic Acid", score: 91 }
        ],
        "Growing": [
          { keyword: "Azelaic Acid", score: 88 },
          { keyword: "Niacinamide", score: 85 },
          { keyword: "Glutathione", score: 82 },
          { keyword: "Bakuchiol", score: 79 },
          { keyword: "Heartleaf", score: 76 }
        ],
        "Early": [
          { keyword: "EGF / FGF", score: 68 },
          { keyword: "Human Stem Cell", score: 65 },
          { keyword: "Raw Vitamin", score: 62 },
          { keyword: "Fullerene", score: 59 },
          { keyword: "Proteoglycan", score: 55 }
        ]
      },
      "Texture": {
        "Actionable": [
          { keyword: "Sheet Mask", score: 98 },
          { keyword: "Lotion (Toner)", score: 96 },
          { keyword: "Enzyme Powder", score: 93 },
          { keyword: "Cleansing Oil", score: 91 },
          { keyword: "All-in-One Gel", score: 89 }
        ],
        "Growing": [
          { keyword: "Needle Shot", score: 86 },
          { keyword: "Toner Pad", score: 83 },
          { keyword: "Booster Serum", score: 80 },
          { keyword: "Balm Cleanser", score: 78 },
          { keyword: "Carbonated Foam", score: 75 }
        ],
        "Early": [
          { keyword: "Melting Balm", score: 68 },
          { keyword: "Freeze-dried", score: 64 },
          { keyword: "Solid Serum", score: 60 },
          { keyword: "Jelly Mist", score: 57 },
          { keyword: "Peel-off Pack", score: 54 }
        ]
      },
      "Effects": {
        "Actionable": [
          { keyword: "Pore Care", score: 98 },
          { keyword: "Whitening", score: 96 },
          { keyword: "Anti-aging", score: 94 },
          { keyword: "Moisturizing", score: 92 },
          { keyword: "Rough Skin", score: 90 }
        ],
        "Growing": [
          { keyword: "Vertical Pores", score: 86 },
          { keyword: "Tone-up", score: 84 },
          { keyword: "Sebum Control", score: 81 },
          { keyword: "Acne Scars", score: 79 },
          { keyword: "Elasticity", score: 76 }
        ],
        "Early": [
          { keyword: "Inner Dryness", score: 68 },
          { keyword: "Blue Light", score: 63 },
          { keyword: "Pollution Care", score: 59 },
          { keyword: "Neck Care", score: 56 },
          { keyword: "Eye Bags", score: 53 }
        ]
      }
    },
    "Cleansing": {
      "Texture": {
        "Actionable": [
          { keyword: "Cleansing Oil", score: 97 },
          { keyword: "Enzyme Powder", score: 94 },
          { keyword: "Cleansing Balm", score: 91 },
          { keyword: "Foam", score: 89 },
          { keyword: "Gel", score: 86 }
        ],
        "Growing": [
          { keyword: "Carbonated Foam", score: 83 },
          { keyword: "Hot Gel", score: 80 },
          { keyword: "Milk", score: 77 },
          { keyword: "Clay Wash", score: 74 },
          { keyword: "Wipe-off Water", score: 71 }
        ],
        "Early": [
          { keyword: "Solid Soap", score: 65 },
          { keyword: "Oil-in-Water", score: 62 },
          { keyword: "Stick Cleanser", score: 59 },
          { keyword: "Serum Wash", score: 56 },
          { keyword: "Peeling Mousse", score: 53 }
        ]
      }
    },
    "Sun Care": {
      "Effects": {
        "Actionable": [
          { keyword: "UV Protection", score: 98 },
          { keyword: "Tone-up", score: 96 },
          { keyword: "Makeup Base", score: 93 },
          { keyword: "Water-proof", score: 91 },
          { keyword: "Non-chemical", score: 88 }
        ],
        "Growing": [
          { keyword: "Beautifying", score: 84 },
          { keyword: "Cooling", score: 81 },
          { keyword: "Pollen Block", score: 78 },
          { keyword: "Stick Type", score: 75 },
          { keyword: "Spray Type", score: 72 }
        ],
        "Early": [
          { keyword: "Hair Sunscreen", score: 65 },
          { keyword: "Lip Sunscreen", score: 62 },
          { keyword: "Drinkable Sun", score: 58 },
          { keyword: "Cushion Sun", score: 55 },
          { keyword: "Patch", score: 52 }
        ]
      }
    },
    "Makeup": {
      "Texture": {
        "Actionable": [
          { keyword: "Cushion Founde", score: 97 },
          { keyword: "Loose Powder", score: 94 },
          { keyword: "Mascara Base", score: 91 },
          { keyword: "Lip Tint", score: 89 },
          { keyword: "Cream Blush", score: 86 }
        ],
        "Growing": [
          { keyword: "Stick Highlighter", score: 83 },
          { keyword: "Liquid Glitter", score: 80 },
          { keyword: "Brow Mascara", score: 77 },
          { keyword: "Melting Lip", score: 74 },
          { keyword: "Concealer Palette", score: 71 }
        ],
        "Early": [
          { keyword: "Lip Plumper", score: 66 },
          { keyword: "Setting Mist", score: 63 },
          { keyword: "Mineral Powder", score: 60 },
          { keyword: "Multi-pencil", score: 57 },
          { keyword: "Stamp Liner", score: 54 }
        ]
      }
    },
    "Hair Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Damage Repair", score: 98 },
          { keyword: "Smoothness (Sarra)", score: 96 },
          { keyword: "Moisturizing", score: 93 },
          { keyword: "Scent", score: 91 },
          { keyword: "Color Care", score: 88 }
        ],
        "Growing": [
          { keyword: "Scalp Care", score: 85 },
          { keyword: "Frizz Control", score: 82 },
          { keyword: "Night Repair", score: 79 },
          { keyword: "Heat Protect", score: 76 },
          { keyword: "Volumizing", score: 73 }
        ],
        "Early": [
          { keyword: "Acid Heat Treat", score: 68 },
          { keyword: "Gray Hair Care", score: 65 },
          { keyword: "Head Spa", score: 61 },
          { keyword: "Hair Water", score: 58 },
          { keyword: "Scalp Essence", score: 55 }
        ]
      }
    },
    "Body Care": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Ceramides", score: 95 },
          { keyword: "Urea", score: 92 },
          { keyword: "Shea Butter", score: 90 },
          { keyword: "Placenta", score: 87 },
          { keyword: "Collagen", score: 85 }
        ],
        "Growing": [
          { keyword: "Cica", score: 82 },
          { keyword: "Vitamin C", score: 79 },
          { keyword: "Job's Tears", score: 76 },
          { keyword: "Retinol", score: 73 },
          { keyword: "White Clay", score: 70 }
        ],
        "Early": [
          { keyword: "CBD", score: 62 },
          { keyword: "Stem Cell", score: 59 },
          { keyword: "Gold", score: 56 },
          { keyword: "Sake Lees", score: 53 },
          { keyword: "Matcha", score: 50 }
        ]
      }
    },
    "Mens Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Sebum Control", score: 94 },
          { keyword: "Pore Care", score: 92 },
          { keyword: "Smell Control", score: 89 },
          { keyword: "After Shave", score: 87 },
          { keyword: "Face Wash", score: 85 }
        ],
        "Growing": [
          { keyword: "BB Cream", score: 82 },
          { keyword: "Eyebrow Trim", score: 79 },
          { keyword: "Lip Care", score: 76 },
          { keyword: "Whitening", score: 73 },
          { keyword: "Hair Removal", score: 70 }
        ],
        "Early": [
          { keyword: "Nail Polish", score: 62 },
          { keyword: "Concealer", score: 59 },
          { keyword: "Anti-aging", score: 56 },
          { keyword: "Eye Makeup", score: 53 },
          { keyword: "Intimate Care", score: 50 }
        ]
      }
    }
  },
  Indonesia: {
    "Skincare": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Niacinamide", score: 99 },
          { keyword: "Salicylic Acid", score: 97 },
          { keyword: "Ceramides", score: 95 },
          { keyword: "Centella", score: 93 },
          { keyword: "Alpha Arbutin", score: 91 }
        ],
        "Growing": [
          { keyword: "SymWhite 377", score: 88 },
          { keyword: "Mugwort", score: 85 },
          { keyword: "Retinal", score: 82 },
          { keyword: "Panthenol", score: 79 },
          { keyword: "Propolis", score: 76 }
        ],
        "Early": [
          { keyword: "Kombucha", score: 68 },
          { keyword: "Sea Buckthorn", score: 65 },
          { keyword: "Cactus Extract", score: 62 },
          { keyword: "Blue Tansy", score: 59 },
          { keyword: "Truffle", score: 55 }
        ]
      },
      "Texture": {
        "Actionable": [
          { keyword: "Gel Moisturizer", score: 98 },
          { keyword: "Clay Stick", score: 97 },
          { keyword: "Toner Pad", score: 94 },
          { keyword: "Sun Gel", score: 92 },
          { keyword: "Micellar Water", score: 90 }
        ],
        "Growing": [
          { keyword: "Skin Tint", score: 86 },
          { keyword: "Mugwort Mask", score: 83 },
          { keyword: "Cleansing Balm", score: 80 },
          { keyword: "Mist", score: 77 },
          { keyword: "Watery Essence", score: 75 }
        ],
        "Early": [
          { keyword: "Modeling Mask", score: 65 },
          { keyword: "Powder Wash", score: 62 },
          { keyword: "Bubble Toner", score: 58 },
          { keyword: "Stick Balm", score: 55 },
          { keyword: "Oil-to-Foam", score: 52 }
        ]
      },
      "Effects": {
        "Actionable": [
          { keyword: "Brightening", score: 99 },
          { keyword: "Acne Care", score: 98 },
          { keyword: "Barrier Repair", score: 95 },
          { keyword: "Oil Control", score: 93 },
          { keyword: "Dark Spot", score: 91 }
        ],
        "Growing": [
          { keyword: "Glowing", score: 86 },
          { keyword: "Pore Tightening", score: 83 },
          { keyword: "Redness", score: 80 },
          { keyword: "Anti-aging", score: 78 },
          { keyword: "Sun Damage", score: 75 }
        ],
        "Early": [
          { keyword: "Glass Skin", score: 68 },
          { keyword: "Fungal Acne", score: 65 },
          { keyword: "Texture Repair", score: 62 },
          { keyword: "Neck Lines", score: 58 },
          { keyword: "Under Eye", score: 55 }
        ]
      }
    },
    "Cleansing": {
      "Texture": {
        "Actionable": [
          { keyword: "Foam Cleanser", score: 98 },
          { keyword: "Micellar Water", score: 96 },
          { keyword: "Gel Cleanser", score: 93 },
          { keyword: "Bar Soap (Acne)", score: 90 },
          { keyword: "Clay Wash", score: 88 }
        ],
        "Growing": [
          { keyword: "Cleansing Balm", score: 85 },
          { keyword: "Cleansing Oil", score: 82 },
          { keyword: "Salicylic Wash", score: 79 },
          { keyword: "Wipes", score: 76 },
          { keyword: "Low pH Gel", score: 73 }
        ],
        "Early": [
          { keyword: "Powder Wash", score: 65 },
          { keyword: "Milk Cleanser", score: 62 },
          { keyword: "Stick Cleanser", score: 59 },
          { keyword: "Jelly Wash", score: 56 },
          { keyword: "Bi-phase", score: 53 }
        ]
      }
    },
    "Sun Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Tone-up", score: 98 },
          { keyword: "Non-sticky", score: 96 },
          { keyword: "No White Cast", score: 94 },
          { keyword: "SPF 50+", score: 92 },
          { keyword: "Blue Light", score: 89 }
        ],
        "Growing": [
          { keyword: "Serum Texture", score: 85 },
          { keyword: "Cooling", score: 82 },
          { keyword: "Mist Spray", score: 79 },
          { keyword: "Acne Safe", score: 76 },
          { keyword: "Water-proof", score: 73 }
        ],
        "Early": [
          { keyword: "Sun Mousse", score: 65 },
          { keyword: "Tinted Sun", score: 62 },
          { keyword: "Cushion Sun", score: 59 },
          { keyword: "Body Sun Stick", score: 56 },
          { keyword: "Shimmer Sun", score: 53 }
        ]
      }
    },
    "Makeup": {
      "Texture": {
        "Actionable": [
          { keyword: "Lip Tint", score: 99 },
          { keyword: "Cushion Founde", score: 97 },
          { keyword: "Loose Powder", score: 95 },
          { keyword: "Matte Lip", score: 92 },
          { keyword: "Eyebrow Pencil", score: 90 }
        ],
        "Growing": [
          { keyword: "Skin Tint", score: 86 },
          { keyword: "Lip Gloss", score: 83 },
          { keyword: "Setting Spray", score: 80 },
          { keyword: "Liquid Blush", score: 77 },
          { keyword: "Cream Contour", score: 74 }
        ],
        "Early": [
          { keyword: "Lip Liner", score: 68 },
          { keyword: "Glitter Gel", score: 65 },
          { keyword: "Soap Brow", score: 62 },
          { keyword: "Freckle Pen", score: 59 },
          { keyword: "Colored Mascara", score: 56 }
        ]
      }
    },
    "Hair Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Anti-hair Loss", score: 98 },
          { keyword: "Scalp Cooling", score: 96 },
          { keyword: "Dandruff Care", score: 94 },
          { keyword: "Scent (Hijab)", score: 92 },
          { keyword: "Smoothness", score: 90 }
        ],
        "Growing": [
          { keyword: "Hair Vitamin", score: 86 },
          { keyword: "Root Lift", score: 83 },
          { keyword: "Dry Shampoo", score: 80 },
          { keyword: "Heat Protect", score: 77 },
          { keyword: "Split Ends", score: 74 }
        ],
        "Early": [
          { keyword: "Scalp Scrub", score: 68 },
          { keyword: "Hair Tonic", score: 65 },
          { keyword: "Hair Perfume", score: 62 },
          { keyword: "Keratin", score: 59 },
          { keyword: "Hair Mask Stick", score: 56 }
        ]
      }
    },
    "Body Care": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Niacinamide", score: 97 },
          { keyword: "Glutathione", score: 95 },
          { keyword: "Goat Milk", score: 92 },
          { keyword: "Vitamin C", score: 90 },
          { keyword: "Scrub Beads", score: 88 }
        ],
        "Growing": [
          { keyword: "AHA", score: 84 },
          { keyword: "Shea Butter", score: 81 },
          { keyword: "Kojic Acid", score: 78 },
          { keyword: "Collagen", score: 75 },
          { keyword: "Ceramides", score: 72 }
        ],
        "Early": [
          { keyword: "Retinol", score: 65 },
          { keyword: "Symwhite", score: 62 },
          { keyword: "Bakuchiol", score: 59 },
          { keyword: "Mugwort", score: 56 },
          { keyword: "Saffron", score: 53 }
        ]
      }
    },
    "Mens Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Oil Control", score: 96 },
          { keyword: "Acne Care", score: 94 },
          { keyword: "Cooling", score: 91 },
          { keyword: "Brightening", score: 89 },
          { keyword: "Face Wash", score: 87 }
        ],
        "Growing": [
          { keyword: "Pore Strip", score: 83 },
          { keyword: "Sunscreen", score: 80 },
          { keyword: "Lip Balm", score: 77 },
          { keyword: "Beard Oil", score: 74 },
          { keyword: "Scrub", score: 71 }
        ],
        "Early": [
          { keyword: "Tone-up Cream", score: 65 },
          { keyword: "Serum", score: 62 },
          { keyword: "Eye Cream", score: 59 },
          { keyword: "Sheet Mask", score: 56 },
          { keyword: "Concealer", score: 53 }
        ]
      }
    }
  },
  Malaysia: {
    "Skincare": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Niacinamide", score: 98 },
          { keyword: "AHA / BHA", score: 95 },
          { keyword: "Vitamin C", score: 93 },
          { keyword: "Aloe Vera", score: 91 },
          { keyword: "Tea Tree", score: 90 }
        ],
        "Growing": [
          { keyword: "Tranexamic Acid", score: 86 },
          { keyword: "Ceramides", score: 83 },
          { keyword: "Snail Mucin", score: 80 },
          { keyword: "Galactomyces", score: 77 },
          { keyword: "Retinol", score: 74 }
        ],
        "Early": [
          { keyword: "Bakuchiol", score: 65 },
          { keyword: "Peptides", score: 62 },
          { keyword: "Bifida", score: 59 },
          { keyword: "Rosehip Oil", score: 56 },
          { keyword: "Grapeseed", score: 53 }
        ]
      },
      "Texture": {
        "Actionable": [
          { keyword: "Gel Cream", score: 97 },
          { keyword: "Sheet Mask", score: 95 },
          { keyword: "Sun Stick", score: 93 },
          { keyword: "Clay Mask", score: 91 },
          { keyword: "Foam Cleanser", score: 89 }
        ],
        "Growing": [
          { keyword: "Sun Serum", score: 85 },
          { keyword: "Sleeping Mask", score: 82 },
          { keyword: "Peeling Gel", score: 79 },
          { keyword: "Lip Oil", score: 76 },
          { keyword: "Toner Pad", score: 73 }
        ],
        "Early": [
          { keyword: "Cleansing Oil", score: 66 },
          { keyword: "Spicule Cream", score: 63 },
          { keyword: "Jelly Mask", score: 60 },
          { keyword: "Mousse", score: 57 },
          { keyword: "Capsule Cream", score: 54 }
        ]
      },
      "Effects": {
        "Actionable": [
          { keyword: "Whitening", score: 99 },
          { keyword: "Oil Control", score: 96 },
          { keyword: "Hydration", score: 93 },
          { keyword: "Spot Fading", score: 91 },
          { keyword: "Pore Care", score: 90 }
        ],
        "Growing": [
          { keyword: "Barrier Repair", score: 85 },
          { keyword: "Glow", score: 82 },
          { keyword: "Anti-aging", score: 79 },
          { keyword: "Soothing", score: 76 },
          { keyword: "Exfoliation", score: 73 }
        ],
        "Early": [
          { keyword: "Skin Resilience", score: 65 },
          { keyword: "Plumping", score: 61 },
          { keyword: "De-puffing", score: 58 },
          { keyword: "Lifting", score: 55 },
          { keyword: "Detox", score: 52 }
        ]
      }
    },
    "Cleansing": {
      "Texture": {
        "Actionable": [
          { keyword: "Foam", score: 97 },
          { keyword: "Micellar Water", score: 95 },
          { keyword: "Gel", score: 92 },
          { keyword: "Scrub Wash", score: 89 },
          { keyword: "Soap Bar", score: 87 }
        ],
        "Growing": [
          { keyword: "Cleansing Balm", score: 84 },
          { keyword: "Oil Cleanser", score: 81 },
          { keyword: "Wipes", score: 78 },
          { keyword: "Clay Wash", score: 75 },
          { keyword: "Low pH", score: 72 }
        ],
        "Early": [
          { keyword: "Powder Wash", score: 65 },
          { keyword: "Milk", score: 62 },
          { keyword: "Stick", score: 59 },
          { keyword: "Mousse", score: 56 },
          { keyword: "Cream", score: 53 }
        ]
      }
    },
    "Sun Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Non-greasy", score: 98 },
          { keyword: "Tone-up", score: 96 },
          { keyword: "Halal Friendly", score: 94 },
          { keyword: "Matte Finish", score: 92 },
          { keyword: "SPF 50+", score: 90 }
        ],
        "Growing": [
          { keyword: "Sun Stick", score: 86 },
          { keyword: "Serum Sun", score: 83 },
          { keyword: "Hydrating", score: 80 },
          { keyword: "No White Cast", score: 77 },
          { keyword: "Glow", score: 74 }
        ],
        "Early": [
          { keyword: "Cushion Sun", score: 68 },
          { keyword: "Tinted", score: 65 },
          { keyword: "Physical UV", score: 62 },
          { keyword: "Mist", score: 59 },
          { keyword: "Body Stick", score: 56 }
        ]
      }
    },
    "Makeup": {
      "Texture": {
        "Actionable": [
          { keyword: "Cushion Founde", score: 96 },
          { keyword: "Lip Matte", score: 94 },
          { keyword: "Loose Powder", score: 92 },
          { keyword: "Eyeliner", score: 90 },
          { keyword: "Compact Powder", score: 88 }
        ],
        "Growing": [
          { keyword: "Lip Tint", score: 85 },
          { keyword: "Setting Spray", score: 82 },
          { keyword: "Liquid Blush", score: 79 },
          { keyword: "Brow Gel", score: 76 },
          { keyword: "Priming Base", score: 73 }
        ],
        "Early": [
          { keyword: "Lip Oil", score: 66 },
          { keyword: "Glossy Stain", score: 63 },
          { keyword: "Stick Blush", score: 60 },
          { keyword: "Glitter", score: 57 },
          { keyword: "Color Corrector", score: 54 }
        ]
      }
    },
    "Hair Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Anti-hair Loss", score: 97 },
          { keyword: "Scalp Care", score: 95 },
          { keyword: "Dandruff", score: 93 },
          { keyword: "Scent", score: 91 },
          { keyword: "Cooling", score: 89 }
        ],
        "Growing": [
          { keyword: "Smoothness", score: 85 },
          { keyword: "Hair Vitamin", score: 82 },
          { keyword: "Root Volume", score: 79 },
          { keyword: "Heat Protect", score: 76 },
          { keyword: "Dry Shampoo", score: 73 }
        ],
        "Early": [
          { keyword: "Scalp Scrub", score: 67 },
          { keyword: "Hair Tonic", score: 64 },
          { keyword: "Vinegar Rinse", score: 61 },
          { keyword: "Hair Perfume", score: 58 },
          { keyword: "Edge Control", score: 55 }
        ]
      }
    },
    "Body Care": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Niacinamide", score: 96 },
          { keyword: "Shea Butter", score: 93 },
          { keyword: "Goat Milk", score: 91 },
          { keyword: "Rose", score: 89 },
          { keyword: "Aloe Vera", score: 87 }
        ],
        "Growing": [
          { keyword: "AHA", score: 84 },
          { keyword: "Vitamin C", score: 81 },
          { keyword: "Ceramides", score: 78 },
          { keyword: "Coffee Scrub", score: 75 },
          { keyword: "Argan Oil", score: 72 }
        ],
        "Early": [
          { keyword: "Retinol", score: 66 },
          { keyword: "Salicylic Acid", score: 63 },
          { keyword: "Pearl", score: 60 },
          { keyword: "Lavender", score: 57 },
          { keyword: "Peptides", score: 54 }
        ]
      }
    },
    "Mens Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Oil Control", score: 95 },
          { keyword: "Acne Care", score: 93 },
          { keyword: "Cooling", score: 91 },
          { keyword: "Face Wash", score: 89 },
          { keyword: "Shaving", score: 87 }
        ],
        "Growing": [
          { keyword: "Pore Care", score: 84 },
          { keyword: "Blackhead", score: 81 },
          { keyword: "Sun Protection", score: 78 },
          { keyword: "Pomade", score: 75 },
          { keyword: "Lip Balm", score: 72 }
        ],
        "Early": [
          { keyword: "Whitening", score: 66 },
          { keyword: "Eye Care", score: 63 },
          { keyword: "Sheet Mask", score: 60 },
          { keyword: "Concealer", score: 57 },
          { keyword: "Toner", score: 54 }
        ]
      }
    }
  },
  Singapore: {
    "Skincare": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Hyaluronic Acid", score: 97 },
          { keyword: "Niacinamide", score: 95 },
          { keyword: "Retinol", score: 93 },
          { keyword: "Vitamin C", score: 91 },
          { keyword: "Ceramides", score: 89 }
        ],
        "Growing": [
          { keyword: "Copper Peptide", score: 85 },
          { keyword: "Retinal", score: 82 },
          { keyword: "Panthenol", score: 80 },
          { keyword: "Resveratrol", score: 77 },
          { keyword: "Ferments", score: 74 }
        ],
        "Early": [
          { keyword: "PDRN", score: 67 },
          { keyword: "Spicule", score: 64 },
          { keyword: "Idebenone", score: 61 },
          { keyword: "Ectoin", score: 58 },
          { keyword: "Beta-Glucan", score: 55 }
        ]
      },
      "Texture": {
        "Actionable": [
          { keyword: "Watery Cream", score: 96 },
          { keyword: "Mist", score: 94 },
          { keyword: "Gel Cleanser", score: 92 },
          { keyword: "Sheet Mask", score: 90 },
          { keyword: "Ampoule", score: 88 }
        ],
        "Growing": [
          { keyword: "Enzyme Powder", score: 85 },
          { keyword: "Multi Balm", score: 82 },
          { keyword: "Sun Serum", score: 79 },
          { keyword: "Toner Pad", score: 76 },
          { keyword: "Soft Peel", score: 73 }
        ],
        "Early": [
          { keyword: "Modeling Pack", score: 68 },
          { keyword: "Needle Shot", score: 65 },
          { keyword: "Freeze-dried", score: 62 },
          { keyword: "Bi-phase Oil", score: 59 },
          { keyword: "Stick Foundation", score: 56 }
        ]
      },
      "Effects": {
        "Actionable": [
          { keyword: "Deep Hydration", score: 98 },
          { keyword: "Anti-aging", score: 95 },
          { keyword: "Firming", score: 92 },
          { keyword: "Radiance", score: 90 },
          { keyword: "Pore Care", score: 89 }
        ],
        "Growing": [
          { keyword: "Barrier Support", score: 86 },
          { keyword: "Texture Smoothing", score: 83 },
          { keyword: "Redness Control", score: 80 },
          { keyword: "V-Shape", score: 77 },
          { keyword: "Dark Circles", score: 74 }
        ],
        "Early": [
          { keyword: "Micro-biome", score: 68 },
          { keyword: "Cellular Repair", score: 65 },
          { keyword: "Hormonal Balance", score: 62 },
          { keyword: "Stress Relief", score: 59 },
          { keyword: "Tech-Neck", score: 56 }
        ]
      }
    },
    "Cleansing": {
      "Texture": {
        "Actionable": [
          { keyword: "Gel Cleanser", score: 95 },
          { keyword: "Micellar Water", score: 93 },
          { keyword: "Cleansing Balm", score: 90 },
          { keyword: "Foam", score: 88 },
          { keyword: "Milk", score: 85 }
        ],
        "Growing": [
          { keyword: "Enzyme Powder", score: 82 },
          { keyword: "Oil Cleanser", score: 79 },
          { keyword: "Acid Wash", score: 76 },
          { keyword: "Clay Wash", score: 73 },
          { keyword: "Lotion", score: 70 }
        ],
        "Early": [
          { keyword: "Cleansing Stick", score: 65 },
          { keyword: "Mousse", score: 62 },
          { keyword: "Essence Wash", score: 59 },
          { keyword: "Soap Bar", score: 56 },
          { keyword: "Cold Cream", score: 53 }
        ]
      }
    },
    "Sun Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Non-sticky", score: 97 },
          { keyword: "SPF 50+", score: 95 },
          { keyword: "Hydrating", score: 93 },
          { keyword: "No White Cast", score: 91 },
          { keyword: "Anti-pollution", score: 89 }
        ],
        "Growing": [
          { keyword: "Glow Finish", score: 85 },
          { keyword: "Serum Sun", score: 82 },
          { keyword: "Blue Light", score: 79 },
          { keyword: "Primer Hybrid", score: 76 },
          { keyword: "Stick", score: 73 }
        ],
        "Early": [
          { keyword: "Oral Sunblock", score: 66 },
          { keyword: "Tinted", score: 63 },
          { keyword: "Scalp Spray", score: 60 },
          { keyword: "Mineral Mousse", score: 57 },
          { keyword: "Cushion Sun", score: 54 }
        ]
      }
    },
    "Makeup": {
      "Texture": {
        "Actionable": [
          { keyword: "Cushion Founde", score: 96 },
          { keyword: "Lip Tint", score: 94 },
          { keyword: "Loose Powder", score: 92 },
          { keyword: "Liquid Blush", score: 90 },
          { keyword: "Concealer", score: 88 }
        ],
        "Growing": [
          { keyword: "Setting Spray", score: 85 },
          { keyword: "Skin Tint", score: 82 },
          { keyword: "Highlighter Stick", score: 79 },
          { keyword: "Lip Oil", score: 76 },
          { keyword: "Brow Pen", score: 73 }
        ],
        "Early": [
          { keyword: "Freckle Pen", score: 67 },
          { keyword: "Glitter Gel", score: 64 },
          { keyword: "Serum Foundation", score: 61 },
          { keyword: "Color Corrector", score: 58 },
          { keyword: "Soap Brow", score: 55 }
        ]
      }
    },
    "Hair Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Anti-hair Loss", score: 96 },
          { keyword: "Scalp Care", score: 94 },
          { keyword: "Damage Repair", score: 92 },
          { keyword: "Frizz Control", score: 90 },
          { keyword: "Volumizing", score: 88 }
        ],
        "Growing": [
          { keyword: "Root Lift", score: 85 },
          { keyword: "Hair Mask", score: 82 },
          { keyword: "Heat Protect", score: 79 },
          { keyword: "Glossing", score: 76 },
          { keyword: "Vinegar Rinse", score: 73 }
        ],
        "Early": [
          { keyword: "Scalp Scrub", score: 68 },
          { keyword: "Bond Builder", score: 65 },
          { keyword: "Peptide Serum", score: 62 },
          { keyword: "Hair Sunscreen", score: 59 },
          { keyword: "Water Treatment", score: 56 }
        ]
      }
    },
    "Body Care": {
      "Ingredients": {
        "Actionable": [
          { keyword: "Niacinamide", score: 95 },
          { keyword: "Ceramides", score: 93 },
          { keyword: "Shea Butter", score: 91 },
          { keyword: "Urea", score: 89 },
          { keyword: "AHA", score: 87 }
        ],
        "Growing": [
          { keyword: "Salicylic Acid", score: 84 },
          { keyword: "Retinol", score: 81 },
          { keyword: "Vitamin C", score: 78 },
          { keyword: "Hyaluronic Acid", score: 75 },
          { keyword: "Tea Tree", score: 72 }
        ],
        "Early": [
          { keyword: "Bakuchiol", score: 67 },
          { keyword: "Pheromones", score: 64 },
          { keyword: "Probiotics", score: 61 },
          { keyword: "CBD", score: 58 },
          { keyword: "Kombucha", score: 55 }
        ]
      }
    },
    "Mens Care": {
      "Effects": {
        "Actionable": [
          { keyword: "Oil Control", score: 95 },
          { keyword: "Pore Care", score: 93 },
          { keyword: "Simple Routine", score: 91 },
          { keyword: "Face Wash", score: 89 },
          { keyword: "Hydration", score: 87 }
        ],
        "Growing": [
          { keyword: "Anti-aging", score: 84 },
          { keyword: "Acne Care", score: 81 },
          { keyword: "Eye Care", score: 78 },
          { keyword: "Sun Protection", score: 75 },
          { keyword: "Lip Balm", score: 72 }
        ],
        "Early": [
          { keyword: "BB Cream", score: 67 },
          { keyword: "Brow Grooming", score: 64 },
          { keyword: "Concealer", score: 61 },
          { keyword: "Beard Oil", score: 58 },
          { keyword: "Sheet Mask", score: 55 }
        ]
      }
    }
  }
};

// Country enum을 문자열 키로 변환
export const getCountryDataKey = (country: Country): string => {
  switch (country) {
    case 'usa': return 'USA';
    case 'japan': return 'Japan';
    case 'indonesia': return 'Indonesia';
    case 'malaysia': return 'Malaysia';
    case 'singapore': return 'Singapore';
    default: return 'USA'; // Fallback for domestic or unsupported
  }
};

// TrendLevel을 TrendStatus로 매핑
const mapTrendLevelToStatus = (level: TrendLevel): TrendStatus => {
  switch (level) {
    case 'Early': return '🌱 Early Trend';
    case 'Growing': return '📈 Growing Trend';
    case 'Actionable': return '🚀 Actionable Trend';
    default: return '📉 Cooling';
  }
};

// 새로운 리더보드 데이터 구조를 BubbleItem 배열로 변환
export const convertLeaderboardToBubbleItems = (
  countryData: CountryLeaderboardData,
  mainCategory: MainCategory,
  itemType: ItemType | null,
  trendLevel: TrendLevel | null,
  country: Country
): BubbleItem[] => {
  const bubbleItems: BubbleItem[] = [];
  const category = countryData[mainCategory];

  if (!category) return [];

  const processItems = (items: LeaderboardItem[], type: ItemType, status: TrendStatus) => {
    items.forEach(item => {
      const bubbleItem: BubbleItem = {
        id: `${mainCategory}-${type}-${status}-${item.keyword}`,
        name: item.keyword,
        type: type === 'Ingredients' ? 'ingredient' : type === 'Texture' ? 'formula' : 'effect',
        x: Math.random() * 100, // Placeholder
        y: Math.random() * 100, // Placeholder
        size: item.score,
        value: item.score,
        status: status,
      };
      bubbleItem.evidence = getTrendEvidence(bubbleItem, country);
      bubbleItem.reviewKeywords = getReviewKeywords(bubbleItem);
      bubbleItems.push(bubbleItem);
    });
  };

  if (itemType && trendLevel) {
    // 특정 타입과 레벨만 처리
    const items = category[itemType]?.[trendLevel];
    if (items) processItems(items, itemType, mapTrendLevelToStatus(trendLevel));
  } else if (itemType) {
    // 특정 타입의 모든 레벨 처리
    Object.entries(category[itemType] || {}).forEach(([levelKey, items]) => {
      if (items) processItems(items, itemType, mapTrendLevelToStatus(levelKey as TrendLevel));
    });
  } else {
    // 모든 타입과 레벨 처리
    Object.entries(category).forEach(([typeKey, typeData]) => {
      Object.entries(typeData || {}).forEach(([levelKey, items]) => {
        if (items) processItems(items, typeKey as ItemType, mapTrendLevelToStatus(levelKey as TrendLevel));
      });
    });
  }

  return bubbleItems.sort((a, b) => b.value - a.value).map((item, index) => ({ ...item, rank: index + 1 }));
};

