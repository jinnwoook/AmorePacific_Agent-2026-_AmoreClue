import { motion, AnimatePresence } from 'framer-motion';
import { X, Copy, Check } from 'lucide-react';
import { useState } from 'react';
import { ReportResult } from '../data/mockData';

interface ReportViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  reportResult: ReportResult | null;
}

export default function ReportViewModal({ isOpen, onClose, reportResult }: ReportViewModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (reportResult?.content) {
      await navigator.clipboard.writeText(reportResult.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (!reportResult) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ type: 'spring', duration: 0.3 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="bg-gradient-to-br from-rose-950/98 to-pink-950/98 backdrop-blur-xl border border-rose-800/50 rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
              {/* 헤더 */}
              <div className="flex items-center justify-between p-6 border-b border-rose-800/30 flex-shrink-0">
                <div>
                  <h2 className="text-2xl font-bold text-white mb-1">
                    {reportResult.type === 'marketing' && '📢 마케팅 캠페인 전략 보고서'}
                    {reportResult.type === 'npd' && '🧪 신제품 기획(BM) 보고서'}
                    {reportResult.type === 'overseas' && '✈️ 해외 진출 전략 보고서'}
                  </h2>
                  <p className="text-sm text-slate-400">AI 기반 맞춤형 보고서</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-4 py-2 bg-rose-900/50 hover:bg-rose-900/70 border border-rose-800/30 rounded-lg text-white text-sm font-medium flex items-center gap-2 transition-all"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4" />
                        복사됨
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        복사
                      </>
                    )}
                  </button>
                  <button
                    onClick={onClose}
                    className="text-slate-400 hover:text-white transition-colors p-2"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
              </div>
              
              {/* 내용 */}
              <div className="flex-1 overflow-y-auto p-6">
                <div className="prose prose-invert max-w-none">
                  <pre className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap font-sans">
                    {reportResult.content}
                  </pre>
                </div>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

