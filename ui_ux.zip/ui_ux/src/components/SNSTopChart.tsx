import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from 'recharts';
import { SNSTopIngredient } from '../data/mockData';
import { motion } from 'framer-motion';
import { Instagram, Music, Youtube } from 'lucide-react';

interface SNSTopChartProps {
  data: SNSTopIngredient[];
}

const getPlatformIcon = (platform: string) => {
  switch (platform) {
    case 'Instagram':
      return Instagram;
    case 'TikTok':
      return Music;
    case 'YouTube':
      return Youtube;
    default:
      return Instagram;
  }
};

const getPlatformColor = (platform: string) => {
  switch (platform) {
    case 'Instagram':
      return { gradient: 'from-pink-500 to-rose-500', bar: '#ec4899' };
    case 'TikTok':
      return { gradient: 'from-cyan-500 to-blue-500', bar: '#06b6d4' };
    case 'YouTube':
      return { gradient: 'from-red-500 to-rose-500', bar: '#ef4444' };
    default:
      return { gradient: 'from-pink-500 to-rose-500', bar: '#ec4899' };
  }
};

export default function SNSTopChart({ data }: SNSTopChartProps) {
  return (
    <div className="space-y-4">
      {data.map((platformData, index) => {
        const Icon = getPlatformIcon(platformData.platform);
        const colors = getPlatformColor(platformData.platform);
        
        return (
          <motion.div
            key={platformData.platform}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/95 backdrop-blur-sm border border-slate-200/80 rounded-xl p-4"
          >
            <div className="flex items-center gap-2 mb-3">
              <Icon className="w-5 h-5 text-rose-600" />
              <h4 className="text-slate-900 font-bold text-base">{platformData.platform}</h4>
              <span className="text-xs text-slate-700 font-semibold">Top 5 성분</span>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={platformData.ingredients} layout="vertical">
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis
                  dataKey="name"
                  type="category"
                  tick={{ fill: '#1e293b', fontSize: 12, fontWeight: 'bold' }}
                  width={80}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(15, 23, 42, 0.98)',
                    border: '1px solid rgba(251, 113, 133, 0.5)',
                    borderRadius: '8px',
                    color: '#ffffff',
                    padding: '8px 12px',
                  }}
                  labelStyle={{
                    color: '#fda4af',
                    fontWeight: 'bold',
                    marginBottom: '4px',
                  }}
                  formatter={(value: number, name: string, props: any) => {
                    const changeText = props.payload.change > 0 ? `+${props.payload.change}` : `${props.payload.change}`;
                    return [`${value}% (${changeText}%)`, '언급량'];
                  }}
                  itemStyle={{
                    color: '#ffffff',
                    fontWeight: 'bold',
                  }}
                />
                <Bar dataKey="value" radius={[0, 8, 8, 0]}>
                  {platformData.ingredients.map((entry, idx) => (
                    <Cell
                      key={`cell-${idx}`}
                      fill={colors.bar}
                      opacity={0.8 - idx * 0.1}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        );
      })}
    </div>
  );
}

