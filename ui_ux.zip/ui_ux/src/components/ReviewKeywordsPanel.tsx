import { motion } from 'framer-motion';
import { ReviewKeywords } from '../data/mockData';
import { ThumbsUp, ThumbsDown, TrendingUp } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell } from 'recharts';

interface ReviewKeywordsPanelProps {
  keywords: ReviewKeywords | null;
  itemName: string;
  isCombination?: boolean; // 꿀조합인지 여부
}

export default function ReviewKeywordsPanel({ keywords, itemName, isCombination = false }: ReviewKeywordsPanelProps) {
  if (!keywords) {
    return (
      <div className="bg-white/95 backdrop-blur-sm border border-slate-200/80 rounded-xl p-6 shadow-xl">
        <p className="text-slate-900 italic text-sm text-center">
          리더보드 항목을 클릭하여 리뷰 키워드를 확인하세요
        </p>
      </div>
    );
  }

  // 꿀조합일 때는 다른 키워드 표시
  const displayKeywords = isCombination ? {
    positive: [
      { keyword: '완벽한 조합', count: Math.floor(keywords.positive[0]?.count || 100) * 1.2 },
      { keyword: '시너지 효과', count: Math.floor(keywords.positive[0]?.count || 100) * 1.1 },
      { keyword: '함께 사용 추천', count: Math.floor(keywords.positive[0]?.count || 100) * 0.9 },
      { keyword: '조합 만족도', count: Math.floor(keywords.positive[0]?.count || 100) * 0.8 },
      { keyword: '효과 배가', count: Math.floor(keywords.positive[0]?.count || 100) * 0.7 },
      { keyword: '상호 보완', count: Math.floor(keywords.positive[0]?.count || 100) * 0.6 },
      { keyword: '조합 완성도', count: Math.floor(keywords.positive[0]?.count || 100) * 0.5 },
    ],
    negative: [
      { keyword: '조합 부적합', count: Math.floor(keywords.negative[0]?.count || 20) * 1.1 },
      { keyword: '효과 중복', count: Math.floor(keywords.negative[0]?.count || 20) * 0.9 },
      { keyword: '사용법 복잡', count: Math.floor(keywords.negative[0]?.count || 20) * 0.8 },
      { keyword: '가격 부담', count: Math.floor(keywords.negative[0]?.count || 20) * 0.7 },
      { keyword: '효과 미미', count: Math.floor(keywords.negative[0]?.count || 20) * 0.6 },
    ]
  } : keywords;

  // 차트 데이터 준비
  const positiveData = displayKeywords.positive
    .sort((a, b) => b.count - a.count)
    .slice(0, 10)
    .map(item => ({ keyword: item.keyword, count: item.count, type: 'positive' }));

  const negativeData = displayKeywords.negative
    .sort((a, b) => b.count - a.count)
    .slice(0, 10)
    .map(item => ({ keyword: item.keyword, count: item.count, type: 'negative' }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/95 backdrop-blur-sm border border-slate-200/80 rounded-xl p-6 shadow-xl"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-slate-900 font-bold text-xl flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-rose-600" />
          리뷰 키워드 분석
        </h3>
        <span className="text-xs text-slate-900 bg-slate-200 px-2 py-1 rounded border border-slate-400 font-semibold">
          {itemName}
        </span>
      </div>

      <div className="space-y-6">
        {/* 긍정 리뷰 키워드 */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <ThumbsUp className="w-4 h-4 text-emerald-400" />
            <h4 className="text-slate-900 font-bold text-base">긍정 리뷰 키워드</h4>
          </div>
          <div className="bg-emerald-50/80 border border-emerald-200/80 rounded-lg p-4">
            <ResponsiveContainer width="100%" height={Math.min(300, positiveData.length * 30)}>
              <BarChart data={positiveData} layout="vertical" margin={{ top: 5, right: 10, bottom: 5, left: 80 }}>
                <XAxis type="number" tick={{ fontSize: 10, fill: '#1e293b', fontWeight: 'bold' }} />
                <YAxis 
                  dataKey="keyword" 
                  type="category" 
                  tick={{ fontSize: 11, fill: '#1e293b', fontWeight: 'bold' }}
                  width={70}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 41, 59, 0.95)', 
                    border: '1px solid rgba(16, 185, 129, 0.3)',
                    borderRadius: '8px',
                    color: '#ffffff'
                  }}
                  itemStyle={{ color: '#ffffff' }}
                  labelStyle={{ color: '#ffffff' }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {positiveData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="#10b981" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-3 flex flex-wrap gap-2">
              {displayKeywords.positive.slice(0, 5).map((item, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 bg-emerald-300 border border-emerald-400 rounded-md text-xs text-slate-900 font-bold"
                >
                  #{item.keyword} (<span className="text-slate-900 font-bold">{item.count}</span>)
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* 부정 리뷰 키워드 */}
        <div>
          <div className="flex items-center gap-2 mb-3">
            <ThumbsDown className="w-4 h-4 text-rose-400" />
            <h4 className="text-slate-900 font-bold text-base">부정 리뷰 키워드</h4>
          </div>
          <div className="bg-rose-50/80 border border-rose-200/80 rounded-lg p-4">
            <ResponsiveContainer width="100%" height={Math.min(300, negativeData.length * 30)}>
              <BarChart data={negativeData} layout="vertical" margin={{ top: 5, right: 10, bottom: 5, left: 80 }}>
                <XAxis type="number" tick={{ fontSize: 10, fill: '#1e293b', fontWeight: 'bold' }} />
                <YAxis 
                  dataKey="keyword" 
                  type="category" 
                  tick={{ fontSize: 11, fill: '#1e293b', fontWeight: 'bold' }}
                  width={70}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(30, 41, 59, 0.95)', 
                    border: '1px solid rgba(244, 63, 94, 0.3)',
                    borderRadius: '8px',
                    color: '#ffffff'
                  }}
                  itemStyle={{ color: '#ffffff' }}
                  labelStyle={{ color: '#ffffff' }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {negativeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill="#f43f5e" />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="mt-3 flex flex-wrap gap-2">
              {displayKeywords.negative.slice(0, 5).map((item, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 bg-rose-300 border border-rose-400 rounded-md text-xs text-slate-900 font-bold"
                >
                  #{item.keyword} (<span className="text-slate-900 font-bold">{item.count}</span>)
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

